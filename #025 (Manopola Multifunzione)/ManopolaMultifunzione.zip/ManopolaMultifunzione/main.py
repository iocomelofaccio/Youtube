import digitalio
import board
import usb_hid
import time
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.mouse import Mouse
from adafruit_hid.keycode import Keycode
from adafruit_hid.consumer_control import ConsumerControl
from adafruit_hid.consumer_control_code import ConsumerControlCode
import displayio
import terminalio
from adafruit_display_text import label
import adafruit_displayio_ssd1306
import busio
from board import GP21, GP20


CLK_PIN = board.GP4
DT_PIN = board.GP3
SW_PIN = board.GP2
clk_last = None
count = 0
totalMode = 6
currentMode = 0
first=1

cc = ConsumerControl(usb_hid.devices)
mouse = Mouse(usb_hid.devices)
keyboard = Keyboard(usb_hid.devices)


clk = digitalio.DigitalInOut(CLK_PIN)
clk.direction = digitalio.Direction.INPUT

dt = digitalio.DigitalInOut(DT_PIN)
dt.direction = digitalio.Direction.INPUT

sw = digitalio.DigitalInOut(SW_PIN)
sw.direction = digitalio.Direction.INPUT
sw.pull = digitalio.Pull.UP

#------------------------------------DISPLAY------------------------------------
displayio.release_displays()
oled_reset = board.GP9
i2c = busio.I2C(GP21, GP20)
display_bus = displayio.I2CDisplay(i2c, device_address=0x3C, reset=oled_reset)

WIDTH = 128
HEIGHT = 32
BORDER = 1

display = adafruit_displayio_ssd1306.SSD1306(display_bus, width=WIDTH, height=HEIGHT)

splash = displayio.Group()
display.show(splash)

color_bitmap = displayio.Bitmap(WIDTH, HEIGHT, 1)
color_palette = displayio.Palette(1)
color_palette[0] = 0xFFFFFF  # White

bg_sprite = displayio.TileGrid(color_bitmap, pixel_shader=color_palette, x=0, y=0)
splash.append(bg_sprite)

# Draw a smaller inner rectangle
inner_bitmap = displayio.Bitmap(WIDTH - BORDER * 2, HEIGHT - BORDER * 2, 1)
inner_palette = displayio.Palette(1)
inner_palette[0] = 0x000000  # Black
inner_sprite = displayio.TileGrid(
    inner_bitmap, pixel_shader=inner_palette, x=BORDER, y=BORDER
)
splash.append(inner_sprite)
time.sleep(0.5)
# Draw a label
text = "IoComeLoFaccio"
text_area = label.Label(terminalio.FONT, text=text, color=0xFFFFFF, x=21, y=HEIGHT // 2-1)
splash.append(text_area)
time.sleep(2)
#display.auto_refresh = True
#-------------------------

def millis():
    return time.monotonic() * 1000

def ccw():
    print("CCW")
    
    if (currentMode == 0):    # Mac brightness down
        keyboard.send(Keycode.SCROLL_LOCK)
        
    elif(currentMode == 1):    # Mac horizontal scroll right
        keyboard.press(Keycode.SHIFT)
        mouse.move(wheel=-1)
        keyboard.release(Keycode.SHIFT)
    
    elif(currentMode == 2):    # Mac vertical scroll right
        mouse.move(wheel=-1)
    
    elif(currentMode == 3):    # Mac horizontal scroll right
        keyboard.press(Keycode.COMMAND)
        mouse.move(wheel=-1)
        keyboard.release(Keycode.COMMAND)
        
    elif(currentMode == 4):    # Mac horizontal scroll right
        keyboard.press(Keycode.OPTION)
        mouse.move(wheel=-1)
        keyboard.release(Keycode.OPTION)
    
    elif(currentMode == 5):   # Volume decrement
        cc.send(ConsumerControlCode.VOLUME_DECREMENT)
        
def cw():
    print("CW")
    if (currentMode == 0):     # Mac brightness up
        keyboard.send(Keycode.PAUSE)              
        
    elif(currentMode == 1):     # Mac horizontal scroll left
        keyboard.press(Keycode.SHIFT)
        mouse.move(wheel=1)
        keyboard.release(Keycode.SHIFT)
    
    elif(currentMode == 2):     # Mac vertical scroll left
        mouse.move(wheel=1)
   
    elif(currentMode == 3):     # Mac horizontal scroll left
        keyboard.press(Keycode.COMMAND)
        mouse.move(wheel=1)
        keyboard.release(Keycode.COMMAND)
    
    elif(currentMode == 4):     # Mac horizontal scroll left
        keyboard.press(Keycode.OPTION)
        mouse.move(wheel=1)
        keyboard.release(Keycode.OPTION)
    
    elif(currentMode == 5):     # Volume increment
        cc.send(ConsumerControlCode.VOLUME_INCREMENT)

        
def long_press():
    #Mac sleep: CMD + OPT + EJECT
    keyboard.press(Keycode.ALT, Keycode.COMMAND)  
    cc.send(ConsumerControlCode.EJECT)
    keyboard.release_all()

while(1):
    clkState = clk.value
    if(clk_last !=  clkState and not first):
        if(dt.value != clkState):
            cw()
        else:
            ccw()
    if(first):
        first=0
        text = "Luminosita'"
        text_area = label.Label(
            terminalio.FONT, text=text, color=0xFFFFFF, x=35, y=HEIGHT // 2 - 1
        )
        splash.pop(-1)
        splash.append(text_area)
        
    if (sw.value == 0):
        pressTime = millis()
        time.sleep(0.2)
        longPress = False
        
        while(sw.value == 0):
            if(millis() - pressTime > 1000 and not longPress):
                print("longPress")
                longPress = True
                long_press()
                

        if (not longPress):
            currentMode += 1
            currentMode %= totalMode
            print("Mode: " + str(currentMode))
            if(currentMode==0):
                text = "Luminosita'"
                text_area = label.Label(
                    terminalio.FONT, text=text, color=0xFFFFFF, x=35, y=HEIGHT // 2 - 1
                )
            elif(currentMode==1):
                text = "Scroll Orizzontale"
                text_area = label.Label(
                    terminalio.FONT, text=text, color=0xFFFFFF, x=10, y=HEIGHT // 2 - 1
                )
            elif(currentMode==2):
                text = "Scroll Verticale"
                text_area = label.Label(
                    terminalio.FONT, text=text, color=0xFFFFFF, x=18, y=HEIGHT // 2 - 1
                )
            elif(currentMode==3):
                text = "Movimento Orizzontale"
                text_area = label.Label(
                    terminalio.FONT, text=text, color=0xFFFFFF, x=1, y=HEIGHT // 2 - 1
                )
            elif(currentMode==4):
                text = "Zoom"
                text_area = label.Label(
                    terminalio.FONT, text=text, color=0xFFFFFF, x=52, y=HEIGHT // 2 - 1
                )
            elif(currentMode==5):
                text = "Volume"
                text_area = label.Label(
                    terminalio.FONT, text=text, color=0xFFFFFF, x=48, y=HEIGHT // 2 - 1
                )
            
            splash.pop(-1)
            splash.append(text_area)
            
    clk_last = clkState
