#include <TimeLib.h>
#include <WiFiUdp.h>
#include <ESP8266WiFi.h>

/*-------- NTP code ----------*/

time_t prevDisplay = 0;

int secondi_u = 0;
int secondi_d = 0;
int minuti_u = 0;
int minuti_d = 0;
int ore_u = 0;
int ore_d = 0;
int giorni_u = 0;
int giorni_d = 0;
int mesi_u = 0;
int mesi_d = 0;
int anni_u = 0;
int anni_d = 0;

const int NTP_PACKET_SIZE = 48; // NTP time is in the first 48 bytes of message
byte packetBuffer[NTP_PACKET_SIZE]; //buffer to hold incoming & outgoing packets
// NTP Servers:
static const char ntpServerName[] = "us.pool.ntp.org";
const int timeZone = 1;

WiFiUDP Udp;

int getDayLight(time_t oggi);

// send an NTP request to the time server at the given address
void sendNTPpacket(IPAddress &address) {
  // set all bytes in the buffer to 0
  memset(packetBuffer, 0, NTP_PACKET_SIZE);
  // Initialize values needed to form NTP request
  // (see URL above for details on the packets)
  packetBuffer[0] = 0b11100011;   // LI, Version, Mode
  packetBuffer[1] = 0;     // Stratum, or type of clock
  packetBuffer[2] = 6;     // Polling Interval
  packetBuffer[3] = 0xEC;  // Peer Clock Precision
  // 8 bytes of zero for Root Delay & Root Dispersion
  packetBuffer[12] = 49;
  packetBuffer[13] = 0x4E;
  packetBuffer[14] = 49;
  packetBuffer[15] = 52;
  // all NTP fields have been given values, now
  // you can send a packet requesting a timestamp:
  Udp.beginPacket(address, 123); //NTP requests are to port 123
  Udp.write(packetBuffer, NTP_PACKET_SIZE);
  Udp.endPacket();
}

time_t getNtpTime() {
  IPAddress ntpServerIP; // NTP server's ip address

  while (Udp.parsePacket() > 0) ; // discard any previously received packets
  Serial.println("Transmit NTP Request");
  // get a random server from the pool
  WiFi.hostByName(ntpServerName, ntpServerIP);
  Serial.print(ntpServerName);
  Serial.print(": ");
  Serial.println(ntpServerIP);
  sendNTPpacket(ntpServerIP);
  uint32_t beginWait = millis();
  while (millis() - beginWait < 1500) {
    int size = Udp.parsePacket();
    if (size >= NTP_PACKET_SIZE) {
      Serial.println("Receive NTP Response");
      Udp.read(packetBuffer, NTP_PACKET_SIZE);  // read packet into the buffer
      unsigned long secsSince1900;
      // convert four bytes starting at location 40 to a long integer
      secsSince1900 =  (unsigned long)packetBuffer[40] << 24;
      secsSince1900 |= (unsigned long)packetBuffer[41] << 16;
      secsSince1900 |= (unsigned long)packetBuffer[42] << 8;
      secsSince1900 |= (unsigned long)packetBuffer[43];
      time_t _now = secsSince1900 - 2208988800UL + timeZone * SECS_PER_HOUR;
      _now = _now + getDayLight(_now) * SECS_PER_HOUR;
      return _now;
    }
  }
  Serial.println("No NTP Response :-(");
  return 0; // return 0 if unable to get the time
}

int getDayLight(time_t oggi) {
  //Ora Solare +0
  if (month(oggi) > 10 || month(oggi) < 3) {
    return 0;
  }

  //Ora legale + 1
  if (month(oggi) > 3 && month(oggi) < 10) {
    return 1;
  }

  if (month(oggi) == 10) {
    if (day(oggi) - weekday(oggi) >= 24) {
      if (weekday(oggi) == 1) {
        if (hour(oggi) >= 3) {
          return 0;
        } else {
          return 1;
        }
      }
      else {
        return 0;
      }
    } else {
      return 1;
    }
  }

  if (month(oggi) == 3) {
    if (day(oggi) - weekday(oggi) >= 24) {
      if (weekday(oggi) == 1) {
        if (hour(oggi) >= 2) {
          return 1;
        } else {
          return 0;
        }
      }
      else {
        return 1;
      }
    } else {
      return 0;
    }
  }
  return 1;
}
