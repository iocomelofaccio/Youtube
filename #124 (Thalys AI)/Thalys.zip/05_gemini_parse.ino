bool handleAudioPayload(uint8_t *payload, size_t length) {
  auto findBytes = [](const uint8_t *haystack, size_t haystackLen, const char *needle) -> const uint8_t * {
    size_t needleLen = strlen(needle);
    if (needleLen == 0 || needleLen > haystackLen) return nullptr;
    for (size_t i = 0; i <= haystackLen - needleLen; i++) {
      if (memcmp(haystack + i, needle, needleLen) == 0) return haystack + i;
    }
    return nullptr;
  };

  auto findJsonStringValue = [&](const uint8_t *start, const uint8_t *end, const char *key, const uint8_t **valueEnd) -> const uint8_t * {
    const uint8_t *keyPos = findBytes(start, end - start, key);
    if (!keyPos) return nullptr;

    const uint8_t *p = keyPos + strlen(key);
    while (p < end && (*p == ' ' || *p == '\n' || *p == '\r' || *p == '\t')) p++;
    if (p >= end || *p != ':') return nullptr;
    p++;
    while (p < end && (*p == ' ' || *p == '\n' || *p == '\r' || *p == '\t')) p++;
    if (p >= end || *p != '"') return nullptr;
    p++;

    const uint8_t *valueStart = p;
    while (p < end) {
      if (*p == '"' && (p == valueStart || *(p - 1) != '\\')) {
        *valueEnd = p;
        return valueStart;
      }
      p++;
    }
    return nullptr;
  };

  const uint8_t *end = payload + length;
  const uint8_t *mimeEnd = nullptr;
  const uint8_t *mimeStart = findJsonStringValue(payload, end, "\"mimeType\"", &mimeEnd);
  if (!mimeStart || !mimeEnd) return false;

  const uint8_t *pcm = findBytes(mimeStart, mimeEnd - mimeStart, "audio/pcm");
  if (!pcm) return false;

  const uint8_t *dataEnd = nullptr;
  const uint8_t *dataStart = findJsonStringValue(mimeEnd, end, "\"data\"", &dataEnd);
  if (!dataStart || !dataEnd || dataEnd <= dataStart) return false;

  size_t b64Len = dataEnd - dataStart;
  size_t audioLen = 0;
  mbedtls_base64_decode(nullptr, 0, &audioLen, dataStart, b64Len);

  uint8_t *audio = (uint8_t *)malloc(audioLen);
  if (!audio) {
    LOG_ERROR("Audio malloc failed");
    return true;
  }

  int rc = mbedtls_base64_decode(audio, audioLen, &audioLen, dataStart, b64Len);
  if (rc != 0) {
    LOG_ERROR("Audio base64 decode failed");
    free(audio);
    return true;
  }

  LOG_DEBUG_KV("Gemini audio bytes=", (uint32_t)audioLen);
  enqueueGeminiAudio(audio, audioLen);
  return true;
}

void handleGeminiMessage(uint8_t *payload, size_t length) {
  bool audioAlreadyHandled = handleAudioPayload(payload, length);

  StaticJsonDocument<768> filter;
  filter["setupComplete"] = true;
  filter["sessionResumptionUpdate"] = true;
  JsonObject serverFilter = filter["serverContent"].to<JsonObject>();
  serverFilter["generationComplete"] = true;
  serverFilter["turnComplete"] = true;
  serverFilter["interrupted"] = true;
  serverFilter["inputTranscription"]["text"] = true;
  serverFilter["outputTranscription"]["text"] = true;
  JsonArray partsFilter = serverFilter["modelTurn"]["parts"].to<JsonArray>();
  JsonObject partFilter = partsFilter.createNestedObject();
  partFilter["text"] = true;
  partFilter["thought"] = true;

  geminiDoc.clear();
  DeserializationError error = deserializeJson(
    geminiDoc,
    payload,
    length,
    DeserializationOption::Filter(filter));
  if (error) {
    String fallbackText;
    if (findJsonTextNearKey(payload, length, "inputTranscription", fallbackText)) {
      LOG_DEBUG_KV("Transcript user fallback: ", fallbackText);
      appendTranscriptChunk(pendingUserTranscript, fallbackText.c_str());
    }
    if (findJsonTextNearKey(payload, length, "outputTranscription", fallbackText)) {
      LOG_DEBUG_KV("Transcript AI fallback: ", fallbackText);
      appendTranscriptChunk(pendingAiTranscript, fallbackText.c_str());
    }

    if (SERIAL_LOG_LEVEL >= 2 || !audioAlreadyHandled) {
      LOG_ERROR_KV("JSON parse failed: ", error.c_str());
      LOG_ERROR_KV("JSON payload bytes: ", (uint32_t)length);
    }
    return;
  }

  if (geminiDoc["setupComplete"].is<JsonObject>()) {
    setupComplete = true;
    LOG_INFO("Gemini setup complete");
#if GEMINI_TEXT_AUDIO_TEST_ON_SETUP
    sendTextAudioTest();
#endif
    return;
  }

  if (geminiDoc["sessionResumptionUpdate"].is<JsonObject>()) {
    return;
  }

  JsonObject serverContent = geminiDoc["serverContent"];
  if (!serverContent.isNull()) {
    bool turnComplete = serverContent["turnComplete"] | false;
    bool interrupted = serverContent["interrupted"] | false;

    if (serverContent["generationComplete"] | false) {
      LOG_INFO("Gemini generation complete");
    }

    const char *userText = serverContent["inputTranscription"]["text"] | nullptr;
    if (userText) {
      LOG_DEBUG_KV("Transcript user: ", userText);
      appendTranscriptChunk(pendingUserTranscript, userText);
    } else {
      String fallbackText;
      if (findJsonTextNearKey(payload, length, "inputTranscription", fallbackText)) {
        LOG_DEBUG_KV("Transcript user fallback: ", fallbackText);
        appendTranscriptChunk(pendingUserTranscript, fallbackText.c_str());
      }
    }

    const char *geminiText = serverContent["outputTranscription"]["text"] | nullptr;
    if (geminiText) {
      LOG_DEBUG_KV("Transcript AI: ", geminiText);
      appendTranscriptChunk(pendingAiTranscript, geminiText);
    } else {
      String fallbackText;
      if (findJsonTextNearKey(payload, length, "outputTranscription", fallbackText)) {
        LOG_DEBUG_KV("Transcript AI fallback: ", fallbackText);
        appendTranscriptChunk(pendingAiTranscript, fallbackText.c_str());
      }
    }

    JsonArray parts = serverContent["modelTurn"]["parts"];
    if (!parts.isNull()) {
      geminiModelResponding = true;
      statusLedSpeaking();
    }
    for (JsonObject part : parts) {
      const char *text = part["text"] | nullptr;
      bool thought = part["thought"] | false;
      if (text && !thought) {
        LOG_DEBUG_KV("Transcript AI text part: ", text);
        appendTranscriptChunk(pendingAiTranscript, text);
      }

      const char *audio64 = part["inlineData"]["data"] | nullptr;
      if (!audio64) continue;
      if (audioAlreadyHandled) continue;

      uint8_t *audio = nullptr;
      size_t audioLen = 0;
      if (base64Decode(audio64, &audio, &audioLen)) {
        LOG_DEBUG_KV("Gemini audio bytes=", (uint32_t)audioLen);
        enqueueGeminiAudio(audio, audioLen);
      }
    }

    if (interrupted) {
      LOG_INFO("Gemini interrupted");
      geminiModelResponding = false;
      statusLedListening();
      clearPendingTranscripts();
      return;
    }

    if (turnComplete) {
      LOG_INFO("Gemini turn complete");
      geminiModelResponding = false;
      if (geminiSessionActive && wsConnected && setupComplete) {
        statusLedListening();
      } else {
        statusLedOff();
      }
      commitPendingTranscripts();
    }
  }
}
