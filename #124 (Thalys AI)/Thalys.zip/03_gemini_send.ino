String jsonEscapeString(const char *text) {
  String escaped;
  if (!text) return escaped;

  while (*text) {
    char c = *text++;
    if (c == '"' || c == '\\') {
      escaped += '\\';
      escaped += c;
    } else if (c == '\n') {
      escaped += "\\n";
    } else if (c == '\r') {
      escaped += "\\r";
    } else if (c == '\t') {
      escaped += "\\t";
    } else {
      escaped += c;
    }
  }

  return escaped;
}

void sendGeminiSetup() {
  String message = "{";
  message += "\"setup\":{";
  message += "\"model\":\"models/";
  message += GEMINI_MODEL;
  message += "\",";
  message += "\"generationConfig\":{\"responseModalities\":[\"AUDIO\"]";
#if GEMINI_USE_SPEECH_CONFIG
  message += ",\"speechConfig\":{\"voiceConfig\":{\"prebuiltVoiceConfig\":{\"voiceName\":\"";
  message += GEMINI_VOICE_NAME;
  message += "\"}},\"languageCode\":\"it-IT\"}";
#endif
  message += "}";

#if GEMINI_USE_MANUAL_PTT || GEMINI_SESSION_TOGGLE_MODE
  message += ",";
  message += "\"realtimeInputConfig\":{\"automaticActivityDetection\":{\"disabled\":true}}";
#endif

#if GEMINI_ENABLE_TRANSCRIPTIONS
  message += ",";
  message += "\"inputAudioTranscription\":{},";
  message += "\"outputAudioTranscription\":{}";
#endif

#if !GEMINI_MINIMAL_AUDIO_SETUP
#if !GEMINI_ENABLE_TRANSCRIPTIONS
  message += ",";
  message += "\"inputAudioTranscription\":{},";
  message += "\"outputAudioTranscription\":{}";
#endif

#if GEMINI_SEND_SYSTEM_INSTRUCTION
  message += ",";
  message += "\"systemInstruction\":{\"parts\":[{\"text\":\"";
  message += jsonEscapeString(GEMINI_SYSTEM_PROMPT);
  message += "\"}]}";
#endif
#endif

  message += "}}";

  sendWsText(message);
  LOG_INFO("Gemini setup sent");
  LOG_DEBUG_KV("Setup JSON: ", message);
}

void sendAudioChunk(const int16_t *samples, size_t sampleCount) {
  if (!wsConnected || !setupComplete) {
    LOG_DEBUG("Audio chunk skipped: WebSocket/setup not ready");
    return;
  }

  String audio64 = base64Encode((const uint8_t *)samples, sampleCount * sizeof(int16_t));
  if (audio64.length() == 0) {
    LOG_ERROR("Base64 encode failed");
    return;
  }

  String message;
  message.reserve(audio64.length() + 128);
  message += "{\"realtimeInput\":{\"audio\":{\"data\":\"";
  message += audio64;
  message += "\",\"mimeType\":\"audio/pcm;rate=16000\"}}}";

  sendWsText(message);
  audioChunksSent++;
}

void sendTextAudioTest() {
  if (!wsConnected || !setupComplete || textAudioTestSent) return;
  textAudioTestSent = true;
  String message = "{\"clientContent\":{\"turns\":[{\"role\":\"user\",\"parts\":[{\"text\":\"Di soltanto: ciao, ti sento.\"}]}],\"turnComplete\":true}}";
  sendWsText(message);
  LOG_INFO("Text audio test sent");
}

void sendActivityStart() {
  LOG_INFO("PTT pressed");
  if (!wsConnected || !setupComplete) {
    LOG_INFO("PTT start skipped: WebSocket/setup not ready");
    return;
  }
  clearPendingTranscripts();
  sendWsText("{\"realtimeInput\":{\"activityStart\":{}}}");
  LOG_INFO("PTT start");
}

void sendActivityEnd() {
  LOG_INFO("PTT released");
  if (!wsConnected || !setupComplete) {
    LOG_INFO("PTT end skipped: WebSocket/setup not ready");
    return;
  }
  sendWsText("{\"realtimeInput\":{\"activityEnd\":{}}}");
  LOG_INFO("PTT end");
}
