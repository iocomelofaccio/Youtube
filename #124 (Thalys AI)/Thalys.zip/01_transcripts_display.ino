String normalizeTranscriptText(const char *text) {
  String s = text ? String(text) : String("");
  s.replace("\n", " ");
  s.replace("\r", " ");
  s.replace(" ,", ",");
  s.replace(" .", ".");
  s.replace(" !", "!");
  s.replace(" ?", "?");
  s.replace(" ;", ";");
  s.replace(" :", ":");
  while (s.indexOf("  ") >= 0) s.replace("  ", " ");
  s.trim();
  return s;
}

String transcriptTextForDisplay(const String &input) {
  String out;
  out.reserve(input.length());

  for (size_t i = 0; i < input.length(); i++) {
    uint8_t c = (uint8_t)input[i];
    if (c == 0xC3 && i + 1 < input.length()) {
      uint8_t n = (uint8_t)input[++i];
      if ((n >= 0xA0 && n <= 0xA5) || (n >= 0x80 && n <= 0x85)) out += (n < 0xA0) ? 'A' : 'a';
      else if ((n >= 0xA8 && n <= 0xAB) || (n >= 0x88 && n <= 0x8B)) out += (n < 0xA0) ? 'E' : 'e';
      else if ((n >= 0xAC && n <= 0xAF) || (n >= 0x8C && n <= 0x8F)) out += (n < 0xA0) ? 'I' : 'i';
      else if ((n >= 0xB2 && n <= 0xB6) || (n >= 0x92 && n <= 0x96)) out += (n < 0xA0) ? 'O' : 'o';
      else if ((n >= 0xB9 && n <= 0xBC) || (n >= 0x99 && n <= 0x9C)) out += (n < 0xA0) ? 'U' : 'u';
      else if (n == 0xA7) out += 'c';
      else if (n == 0x87) out += 'C';
      else if (n == 0xB1) out += 'n';
      else if (n == 0x91) out += 'N';
      continue;
    }
    out += (char)c;
  }

  return out;
}

bool isTranscriptPunctuation(char c) {
  return c == ',' || c == '.' || c == '!' || c == '?' || c == ';' || c == ':' || c == ')' || c == ']';
}

void appendTranscriptChunk(String &target, const char *text) {
  String chunk = text ? String(text) : String("");
  chunk.replace("\n", " ");
  chunk.replace("\r", " ");

  String clean = chunk;
  clean.trim();
  if (clean.length() == 0) return;

  bool startsWithSpace = chunk.length() > 0 && isspace((unsigned char)chunk[0]);

  if (target.length() == 0) {
    target += clean;
  } else if (startsWithSpace) {
    target += chunk;
  } else {
    char last = target[target.length() - 1];
    char first = clean[0];
    bool joinFragment = !isspace((unsigned char)last) && !isTranscriptPunctuation(last) && !isTranscriptPunctuation(first) && clean.length() <= 3;

    if (isspace((unsigned char)last) || isTranscriptPunctuation(first) || joinFragment) {
      target += clean;
    } else {
      target += " ";
      target += clean;
    }
  }

  transcriptCommitScheduled = true;
  lastTranscriptUpdateAtMs = millis();
}

void pushTranscript(String *history, uint8_t &count, const String &text) {
  String clean = normalizeTranscriptText(text.c_str());
  if (clean.length() == 0) return;

  if (count < TRANSCRIPT_HISTORY_MAX) {
    history[count++] = clean;
    return;
  }

  for (uint8_t i = 0; i < TRANSCRIPT_HISTORY_MAX - 1; i++) {
    history[i] = history[i + 1];
  }
  history[TRANSCRIPT_HISTORY_MAX - 1] = clean;
}

void commitPendingTranscripts() {
  String userText = normalizeTranscriptText(pendingUserTranscript.c_str());
  String aiText = normalizeTranscriptText(pendingAiTranscript.c_str());

  if (userText.length() > 0) {
    pushTranscript(userTranscript, userTranscriptCount, userText);
    LOG_INFO_KV("Transcript user final: ", userText);
    String displayText = transcriptTextForDisplay(userText);
    chat.user(displayText.c_str());
  }

  if (aiText.length() > 0) {
    pushTranscript(aiTranscript, aiTranscriptCount, aiText);
    LOG_INFO_KV("Transcript AI final: ", aiText);
    String displayText = transcriptTextForDisplay(aiText);
    chat.ai(displayText.c_str());
  }

  pendingUserTranscript = "";
  pendingAiTranscript = "";
  transcriptCommitScheduled = false;

  if (SERIAL_LOG_LEVEL >= 2) {
    Serial.print("Transcript saved: user=");
    Serial.print(userTranscriptCount);
    Serial.print(" ai=");
    Serial.println(aiTranscriptCount);
  }
}

void clearPendingTranscripts() {
  pendingUserTranscript = "";
  pendingAiTranscript = "";
  transcriptCommitScheduled = false;
}

void commitStaleTranscripts() {
  if (!transcriptCommitScheduled) return;
  if (wasPttPressed) return;
  if (millis() - lastTranscriptUpdateAtMs < 3500) return;

  LOG_INFO("Transcript fallback commit");
  commitPendingTranscripts();
}

void setupDisplay() {
#if TFT_ENABLED
  LOG_INFO("Starting ST7789 display...");
#if TFT_BL >= 0
  pinMode(TFT_BL, OUTPUT);
  digitalWrite(TFT_BL, HIGH);
#endif
  tft.init(TFT_WIDTH, TFT_HEIGHT);
  tft.setRotation(TFT_ROTATION);
  tft.fillScreen(ST77XX_BLACK);
#endif
}

void printPayload(const char *label, uint8_t *payload, size_t length) {
#if SERIAL_LOG_LEVEL >= 3
  Serial.print(label);
  Serial.print(" (");
  Serial.print(length);
  Serial.print(" bytes): ");
  if (!payload || length == 0) {
    Serial.println("<empty>");
    return;
  }

  size_t n = min(length, (size_t)300);
  for (size_t i = 0; i < n; i++) {
    char c = (char)payload[i];
    Serial.print(isPrintable(c) ? c : '.');
  }
  if (length > n) Serial.print("...");
  Serial.println();
#else
  (void)label;
  (void)payload;
  (void)length;
#endif
}

