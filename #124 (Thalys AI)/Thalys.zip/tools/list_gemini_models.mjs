import fs from "node:fs";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "..");
const secretsPath = path.join(root, "parameters.h");

function readDefine(name, fallback = "") {
  if (!fs.existsSync(secretsPath)) return fallback;
  const text = fs.readFileSync(secretsPath, "utf8");
  const match = text.match(new RegExp(`#define\\s+${name}\\s+"([^"]+)"`));
  return match ? match[1] : fallback;
}

const apiKey = readDefine("GEMINI_API_KEY");

if (!apiKey || apiKey === "YOUR_GEMINI_API_KEY") {
  console.error("Missing GEMINI_API_KEY in parameters.h");
  process.exit(1);
}

const url = `https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(apiKey)}`;
const response = await fetch(url);
const body = await response.json();

if (!response.ok) {
  console.error(JSON.stringify(body, null, 2));
  process.exit(2);
}

const models = body.models ?? [];
for (const model of models) {
  const name = model.name ?? "";
  const methods = model.supportedGenerationMethods ?? [];
  if (/live|audio|tts|flash/i.test(name) || methods.some((m) => /bidi|live/i.test(m))) {
    console.log(`${name} :: ${methods.join(", ")}`);
  }
}
