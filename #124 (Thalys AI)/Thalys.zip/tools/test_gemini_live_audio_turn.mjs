import fs from "node:fs";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "..");
const secretsPath = path.join(root, "parameters.h");

function readDefine(name, fallback = "") {
  if (!fs.existsSync(secretsPath)) return fallback;
  const text = fs.readFileSync(secretsPath, "utf8");
  const match = text.match(new RegExp(`#define\\s+${name}\\s+"([^"]+)"`));
  return match ? match[1] : fallback;
}

const apiKey = readDefine("GEMINI_API_KEY");
const model = process.argv[2] || "gemini-2.5-flash-native-audio-latest";

if (!apiKey || apiKey === "YOUR_GEMINI_API_KEY") {
  console.error("Missing GEMINI_API_KEY in parameters.h");
  process.exit(1);
}

const url =
  "wss://generativelanguage.googleapis.com/ws/" +
  "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent" +
  `?key=${encodeURIComponent(apiKey)}`;

console.log(`Connecting with model: ${model}`);
const ws = new WebSocket(url);
let gotSetup = false;
let gotAudio = false;
let gotText = false;

const timeout = setTimeout(() => {
  console.error(`Timed out. gotSetup=${gotSetup} gotAudio=${gotAudio} gotText=${gotText}`);
  ws.close();
  process.exitCode = 2;
}, 20000);

ws.addEventListener("open", () => {
  console.log("WebSocket open");
  const setup = {
    setup: {
      model: `models/${model}`,
      generationConfig: {
        responseModalities: ["AUDIO"],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: {
              voiceName: "Aoede",
            },
          },
          languageCode: "it-IT",
        },
      },
    },
  };
  console.log(`Sending setup: ${JSON.stringify(setup)}`);
  ws.send(JSON.stringify(setup));
});

ws.addEventListener("message", async (event) => {
  const data =
    typeof event.data === "string"
      ? event.data
      : event.data && typeof event.data.text === "function"
        ? await event.data.text()
        : String(event.data);

  console.log("Message:", data.length > 800 ? `${data.slice(0, 800)}...` : data);
  const parsed = JSON.parse(data);

  if (parsed.setupComplete !== undefined && !gotSetup) {
    gotSetup = true;
    const turn = {
      clientContent: {
        turns: [
          {
            role: "user",
            parts: [{ text: "Di soltanto: ciao, ti sento." }],
          },
        ],
        turnComplete: true,
      },
    };
    console.log(`Sending text turn: ${JSON.stringify(turn)}`);
    ws.send(JSON.stringify(turn));
  }

  const parts = parsed.serverContent?.modelTurn?.parts ?? [];
  for (const part of parts) {
    if (part.inlineData?.data) {
      gotAudio = true;
      console.log(`AUDIO inlineData mime=${part.inlineData.mimeType} base64Len=${part.inlineData.data.length}`);
    }
    if (part.text) {
      gotText = true;
      console.log(`TEXT part: ${part.text.slice(0, 200)}`);
    }
  }

  if (parsed.serverContent?.turnComplete) {
    clearTimeout(timeout);
    console.log(`Done. gotAudio=${gotAudio} gotText=${gotText}`);
    ws.close();
    process.exitCode = gotAudio ? 0 : 3;
  }
});

ws.addEventListener("error", (event) => {
  console.error("WebSocket error:", event.message || event.type);
});

ws.addEventListener("close", (event) => {
  clearTimeout(timeout);
  console.log(`WebSocket close: code=${event.code} reason=${event.reason || "<empty>"}`);
});
