import fs from "node:fs";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "..");
const secretsPath = path.join(root, "parameters.h");

function readDefine(name, fallback = "") {
  if (!fs.existsSync(secretsPath)) return fallback;
  const text = fs.readFileSync(secretsPath, "utf8");
  const match = text.match(new RegExp(`#define\\s+${name}\\s+"([^"]+)"`));
  return match ? match[1] : fallback;
}

const apiKey = readDefine("GEMINI_API_KEY");
const model = process.argv[2] || "gemini-2.5-flash-native-audio-latest";

if (!apiKey || apiKey === "YOUR_GEMINI_API_KEY") {
  console.error("Missing GEMINI_API_KEY in parameters.h");
  process.exit(1);
}

const url =
  "wss://generativelanguage.googleapis.com/ws/" +
  "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent" +
  `?key=${encodeURIComponent(apiKey)}`;

console.log(`Connecting with model: ${model}`);
const ws = new WebSocket(url);

const timeout = setTimeout(() => {
  console.error("Timed out waiting for setupComplete");
  ws.close();
  process.exitCode = 2;
}, 15000);

ws.addEventListener("open", () => {
  console.log("WebSocket open");
  const setup = {
    setup: {
      model: `models/${model}`,
      generationConfig: {
        responseModalities: ["AUDIO"],
      },
      realtimeInputConfig: {
        automaticActivityDetection: {
          disabled: true,
        },
      },
      systemInstruction: {
        parts: [{ text: "You are a helpful assistant." }],
      },
    },
  };
  const payload = JSON.stringify(setup);
  console.log(`Sending setup: ${payload}`);
  ws.send(payload);
});

ws.addEventListener("message", async (event) => {
  const data =
    typeof event.data === "string"
      ? event.data
      : event.data && typeof event.data.text === "function"
        ? await event.data.text()
        : String(event.data);

  console.log("Message:", data);
  try {
    const parsed = JSON.parse(data);
    if (parsed.setupComplete !== undefined) {
      clearTimeout(timeout);
      console.log("OK: setupComplete received");
      ws.close();
    }
  } catch {
    // Keep printing raw messages.
  }
});

ws.addEventListener("error", (event) => {
  console.error("WebSocket error:", event.message || event.type);
});

ws.addEventListener("close", (event) => {
  clearTimeout(timeout);
  console.log(`WebSocket close: code=${event.code} reason=${event.reason || "<empty>"}`);
});
