#include "ChatDisplay.h"
#include <Fonts/FreeSans9pt7b.h>
#include <Fonts/FreeSansBold9pt7b.h>
#include <string.h>

ChatDisplay::ChatDisplay(Adafruit_ST7789 &display)
  : _tft(display),
    _canvas(nullptr),
    _chatFont(&FreeSans9pt7b),
    _headerFont(&FreeSansBold9pt7b) {}

void ChatDisplay::begin(const char *title) {
  _headerHeight = 25;
  _lineHeight = 17;
  _margin = 4;
  _chatBaseline = 13;
  _width = _tft.width();
  _height = _tft.height();

  _backgroundColor = ST77XX_BLACK;
  _headerColor = ST77XX_BLUE;
  _headerTextColor = ST77XX_WHITE;
  _userColor = ST77XX_WHITE;
  _aiColor = ST77XX_GREEN;
  _systemColor = ST77XX_CYAN;
  _infoColor = ST77XX_YELLOW;
  _errorColor = ST77XX_RED;

  _head = 0;
  _count = 0;
  strncpy(_title, title, sizeof(_title) - 1);
  _title[sizeof(_title) - 1] = 0;

  _tft.fillScreen(_backgroundColor);

  _canvas = new GFXcanvas16(
    _width,
    _height - _headerHeight);
  if (_canvas == nullptr) {
    Serial.println("Canvas allocation failed");
    return;
  }
  refreshHeader();
  refreshChat();
}

void ChatDisplay::clear() {
  _head = 0;
  _count = 0;
  refreshChat();
}

void ChatDisplay::setTitle(const char *title) {
  strncpy(_title, title, sizeof(_title) - 1);
  _title[sizeof(_title) - 1] = 0;
  refreshHeader();
}

void ChatDisplay::user(const char *t) {
  addMessage(t, _userColor, false);
}
void ChatDisplay::ai(const char *t) {
  addMessage(t, _aiColor, true);
}
void ChatDisplay::system(const char *t) {
  addMessage(t, _systemColor, false);
}
void ChatDisplay::info(const char *t) {
  addMessage(t, _infoColor, false);
}
void ChatDisplay::error(const char *t) {
  addMessage(t, _errorColor, false);
}

void ChatDisplay::addMessage(const char *text, uint16_t color, bool align) {
  wrapText(text, color, align);
  refreshChat();
}

void ChatDisplay::pushLine(const char *txt, uint16_t color, bool align) {
  strncpy(_history[_head].text, txt, CHAT_MAX_LINE_LENGTH - 1);
  _history[_head].text[CHAT_MAX_LINE_LENGTH - 1] = 0;
  _history[_head].color = color;
  _history[_head].rightAlign = align;
  _head = (_head + 1) % CHAT_MAX_LINES;
  if (_count < CHAT_MAX_LINES) _count++;
}

uint16_t ChatDisplay::textWidth(const char *t) {
  int16_t x1, y1;
  uint16_t w, h;
  if (_canvas) {
    _canvas->setFont(_chatFont);
    _canvas->setTextSize(1);
    _canvas->getTextBounds((char *)t, 0, 0, &x1, &y1, &w, &h);
  } else {
    _tft.setFont(_chatFont);
    _tft.setTextSize(1);
    _tft.getTextBounds((char *)t, 0, 0, &x1, &y1, &w, &h);
  }
  return w;
}

void ChatDisplay::wrapText(const char *text, uint16_t color, bool align) {
  char line[CHAT_MAX_LINE_LENGTH] = { 0 };
  uint16_t len = 0;
  while (*text) {
    if (*text == '\n') {
      line[len] = 0;
      pushLine(line, color, align);
      len = 0;
      line[0] = 0;
      text++;
      continue;
    }

    if (len >= CHAT_MAX_LINE_LENGTH - 1) {
      line[len] = 0;
      pushLine(line, color, align);
      len = 0;
      line[0] = 0;
    }

    line[len++] = *text++;
    line[len] = 0;

    if (textWidth(line) > (_width - _margin * 2)) {
      while (len && line[len - 1] != ' ') len--;
      if (len == 0) len = CHAT_MAX_LINE_LENGTH - 2;
      char rest[CHAT_MAX_LINE_LENGTH];
      strcpy(rest, &line[len]);
      line[len] = 0;
      pushLine(line, color, align);
      strcpy(line, rest);
      len = strlen(line);
    }
  }
  if (len) pushLine(line, color, align);
}

uint16_t ChatDisplay::visibleLines() const {
  return (_height - _headerHeight - _margin) / _lineHeight;
}

void ChatDisplay::drawHeader() {
  _tft.fillRect(0, 0, _width, _headerHeight, _headerColor);
  _tft.setFont(_headerFont);
  _tft.setTextSize(1);
  _tft.setCursor(4, 18);
  _tft.setTextColor(_headerTextColor);
  _tft.drawBitmap(
    _width - 25, 1,
    robotFace,
    ROBOT_W, ROBOT_H,
    ST77XX_WHITE,
    _headerColor
  );
  _tft.print(_title);
}

void ChatDisplay::drawChat() {
  _canvas->fillRect(0, 0, _width, _height - _headerHeight, 0X0101);  //_backgroundColor);
  _canvas->setFont(_chatFont);
  _canvas->setTextSize(1);
  uint16_t vis = visibleLines();
  uint16_t lines = _count < vis ? _count : vis;
  int y = (_height - _margin - _headerHeight - _lineHeight) - ((lines - 1) * _lineHeight) + _chatBaseline;

  int idx = (_head + CHAT_MAX_LINES - lines) % CHAT_MAX_LINES;

  for (uint16_t i = 0; i < lines; i++) {

    int x;
    if (_history[idx].rightAlign) {
      x = _width - _margin - textWidth(_history[idx].text);
      if (x < (int)_margin) x = _margin;
    } else {
      x = _margin;
    }

    _canvas->setCursor(x, y);
    //_tft.setCursor(_margin, y);

    _canvas->setTextColor(_history[idx].color);
    _canvas->print(_history[idx].text);
    y += _lineHeight;
    idx = (idx + 1) % CHAT_MAX_LINES;
  }
}

void ChatDisplay::refreshChat() {
  drawChat();
  _tft.drawRGBBitmap(
    0,
    _headerHeight,
    _canvas->getBuffer(),
    _width,
    _height - _headerHeight);
}

void ChatDisplay::refreshHeader() {
  drawHeader();
}
