static const uint8_t STATUS_LED_OFF = 0;
static const uint8_t STATUS_LED_LISTENING = 1;
static const uint8_t STATUS_LED_SPEAKING = 2;

uint8_t currentStatusLedState = STATUS_LED_OFF;

void writeStatusLed(uint8_t red, uint8_t green, uint8_t blue) {
#if STATUS_RGB_LED_ENABLED
  rgbLedWrite(STATUS_RGB_LED_PIN, red, green, blue);
#else
  (void)red;
  (void)green;
  (void)blue;
#endif
}

void setStatusLed(uint8_t state) {
  if (currentStatusLedState == state) return;
  currentStatusLedState = state;

  switch (state) {
    case STATUS_LED_LISTENING:
      writeStatusLed(0, STATUS_RGB_LED_BRIGHTNESS, 0);
      break;
    case STATUS_LED_SPEAKING:
      writeStatusLed(STATUS_RGB_LED_BRIGHTNESS, 0, 0);
      break;
    case STATUS_LED_OFF:
    default:
      writeStatusLed(0, 0, 0);
      break;
  }
}

void setupStatusLed() {
#if STATUS_RGB_LED_ENABLED
  pinMode(STATUS_RGB_LED_PIN, OUTPUT);
#endif
  currentStatusLedState = STATUS_LED_SPEAKING;
  statusLedOff();
}

void statusLedOff() {
  setStatusLed(STATUS_LED_OFF);
}

void statusLedListening() {
  setStatusLed(STATUS_LED_LISTENING);
}

void statusLedSpeaking() {
  setStatusLed(STATUS_LED_SPEAKING);
}
