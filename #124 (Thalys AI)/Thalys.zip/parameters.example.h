#pragma once  // Evita inclusioni multiple di questo file durante la compilazione.

// ============================================================
// Wi-Fi
// ============================================================

#define WIFI_SSID "YOUR_WIFI_SSID"  // Nome della rete Wi-Fi a cui collegare ESP32.
#define WIFI_PASSWORD "YOUR_WIFI_PASSWORD"  // Password della rete Wi-Fi.

// ============================================================
// Credenziali Gemini
// ============================================================

#define GEMINI_API_KEY "YOUR_GEMINI_API_KEY"  // Chiave API o token per accedere a Gemini Live.
#define GEMINI_USE_EPHEMERAL_TOKEN 0  // 0 = usa API key normale; 1 = usa token effimero generato da backend.
#define GEMINI_USE_QUERY_KEY 1  // 1 = invia la chiave come parametro ?key=; 0 = usa header x-goog-api-key.

// ============================================================
// Modello e comportamento Gemini
// ============================================================

#define GEMINI_MODEL_NAME "gemini-2.5-flash-native-audio-latest"  // Modello Gemini Live con supporto audio nativo.
#define GEMINI_SEND_SYSTEM_INSTRUCTION 1  // 1 = invia il prompt iniziale di sistema a Gemini.
#define GEMINI_SYSTEM_PROMPT "Il tuo nome e Thalys sei un assistente vocale in italiano. Io sono Emanuele ed ho un canale Youtube che si chiama IoComeLoFaccio. Rispondi in modo breve, naturale e utile."  // Prompt iniziale dell'assistente.
#define GEMINI_USE_SPEECH_CONFIG 1  // 1 = invia configurazione voce e lingua per la risposta audio.
#define GEMINI_VOICE_NAME "Aoede"  // Nome della voce Gemini usata per la sintesi audio.
#define GEMINI_TEXT_AUDIO_TEST_ON_SETUP 0  // 1 = invia un breve test testuale dopo il setup per verificare l'audio in uscita.
#define GEMINI_MINIMAL_AUDIO_SETUP 0  // 1 = riduce il setup Gemini al minimo per debug audio.
#define GEMINI_ENABLE_TRANSCRIPTIONS 1  // 1 = richiede trascrizione input utente e output AI.
#define TRANSCRIPT_HISTORY_MAX 20  // Numero massimo di messaggi salvati negli array delle trascrizioni.

// ============================================================
// Log seriale
// ============================================================

#define SERIAL_LOG_LEVEL 1  // 0 = silenzioso, 1 = errori, 2 = stato, 3 = debug dettagliato.

// ============================================================
// Pulsante PTT / Toggle sessione
// ============================================================

#define GEMINI_USE_MANUAL_PTT 1  // 1 = abilita la logica legata al pulsante PTT.
#define GEMINI_SESSION_TOGGLE_MODE 1  // 1 = un click avvia la sessione Gemini, un altro click la ferma.
#define PTT_PIN 8  // GPIO del pulsante esterno collegato a GND.
#define PTT_ACTIVE_LOW 1  // 1 = pulsante premuto quando il pin legge LOW.
#define PTT_USE_INTERNAL_PULLUP 1  // 1 = abilita la pull-up interna sul pin del pulsante.
#define PTT_MAX_HOLD_MS 4500  // Durata massima di pressione nella vecchia modalita push-to-talk.

// ============================================================
// LED RGB onboard
// ============================================================

#define STATUS_RGB_LED_ENABLED 1  // 1 = abilita il LED RGB onboard come indicatore di stato.
#define STATUS_RGB_LED_PIN 48  // GPIO del LED RGB onboard; su molte ESP32-S3 e il pin 48.
#define STATUS_RGB_LED_BRIGHTNESS 32  // Luminosita del LED RGB da 0 a 255.

// ============================================================
// Speaker MAX98357A
// ============================================================

#define SPEAKER_TEST_TONE_ON_BOOT 0  // 1 = riproduce toni di test all'avvio.
#define SPEAKER_VOLUME_PERCENT 70  // Volume software della risposta audio in percentuale.
#define SPEAKER_JITTER_BUFFER_CHUNKS 3  // Numero di chunk audio da accumulare prima della riproduzione.
#define SPEAKER_JITTER_BUFFER_MS 150  // Attesa massima del jitter buffer audio in millisecondi.

// ============================================================
// Display ST7789
// ============================================================

#define TFT_ENABLED 1  // 1 = abilita il display ST7789.
#define TFT_CS 41  // Pin Chip Select del display.
#define TFT_RST 45  // Pin Reset del display.
#define TFT_DC 40  // Pin Data/Command del display.
#define TFT_MOSI 47  // Pin dati SPI verso il display.
#define TFT_SCLK 21  // Pin clock SPI del display.
#define TFT_BL 42  // Pin backlight/LED del display.
#define TFT_WIDTH 240  // Larghezza del display in pixel.
#define TFT_HEIGHT 240  // Altezza del display in pixel.
#define TFT_ROTATION 2  // Rotazione del display; 2 = ruotato di 180 gradi.

// ============================================================
// Microfono INMP441
// ============================================================

#define MIC_CHANNEL_LEFT 1  // 1 = legge il canale sinistro; 0 = legge il canale destro.
#define MIC_GAIN_SHIFT 4  // Guadagno software del microfono: 4 equivale circa a x16.

// ============================================================
// VAD locale
// ============================================================

#define LOCAL_VAD_START_AVG 550  // Soglia media per riconoscere l'inizio della voce.
#define LOCAL_VAD_START_MAX 3500  // Soglia di picco per riconoscere l'inizio della voce.
#define LOCAL_VAD_STOP_AVG 260  // Soglia media sotto cui considerare silenzio.
#define LOCAL_VAD_SILENCE_MS 1200  // Millisecondi di silenzio necessari per chiudere il turno.
#define LOCAL_VAD_MAX_TURN_MS 12000  // Durata massima di un turno prima di forzare activityEnd.
