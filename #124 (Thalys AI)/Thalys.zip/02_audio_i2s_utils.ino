String base64Encode(const uint8_t *data, size_t len) {
  size_t outLen = 0;
  mbedtls_base64_encode(nullptr, 0, &outLen, data, len);

  String encoded;
  encoded.reserve(outLen + 1);

  uint8_t *out = (uint8_t *)malloc(outLen + 1);
  if (!out) return "";

  if (mbedtls_base64_encode(out, outLen + 1, &outLen, data, len) != 0) {
    free(out);
    return "";
  }

  out[outLen] = '\0';
  encoded = (char *)out;
  free(out);
  return encoded;
}

bool base64Decode(const char *input, uint8_t **outData, size_t *outLen) {
  *outData = nullptr;
  *outLen = 0;

  size_t inputLen = strlen(input);
  mbedtls_base64_decode(nullptr, 0, outLen, (const uint8_t *)input, inputLen);

  *outData = (uint8_t *)malloc(*outLen);
  if (!*outData) return false;

  int rc = mbedtls_base64_decode(*outData, *outLen, outLen, (const uint8_t *)input, inputLen);
  if (rc != 0) {
    free(*outData);
    *outData = nullptr;
    *outLen = 0;
    return false;
  }

  return true;
}

bool findJsonTextNearKey(uint8_t *payload, size_t length, const char *anchorKey, String &out) {
  out = "";
  if (!payload || length == 0 || !anchorKey) return false;

  auto findBounded = [](const char *haystack, size_t haystackLen, const char *needle) -> const char * {
    size_t needleLen = strlen(needle);
    if (needleLen == 0 || needleLen > haystackLen) return nullptr;
    for (size_t i = 0; i <= haystackLen - needleLen; i++) {
      if (memcmp(haystack + i, needle, needleLen) == 0) return haystack + i;
    }
    return nullptr;
  };

  String anchor = "\"";
  anchor += anchorKey;
  anchor += "\"";

  const char *start = (const char *)payload;
  const char *end = start + length;
  const char *anchorPos = findBounded(start, length, anchor.c_str());
  if (!anchorPos || anchorPos >= end) return false;

  const char *textPos = findBounded(anchorPos, end - anchorPos, "\"text\"");
  if (!textPos || textPos >= end) return false;

  const char *p = textPos;
  while (p < end && *p != ':') p++;
  if (!p || p >= end) return false;
  p++;

  while (p < end && (*p == ' ' || *p == '\n' || *p == '\r' || *p == '\t')) p++;
  if (p >= end || *p != '"') return false;
  p++;

  while (p < end) {
    char c = *p++;
    if (c == '"') break;
    if (c == '\\' && p < end) {
      char escaped = *p++;
      if (escaped == 'n' || escaped == 'r' || escaped == 't') {
        out += ' ';
      } else {
        out += escaped;
      }
      continue;
    }
    out += c;
  }

  String check = out;
  check.trim();
  return check.length() > 0;
}

void setupMicI2S() {
  i2s_config_t config = {};
  config.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX);
  config.sample_rate = MIC_SAMPLE_RATE;
  config.bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT;
  config.channel_format = MIC_CHANNEL_LEFT ? I2S_CHANNEL_FMT_ONLY_LEFT : I2S_CHANNEL_FMT_ONLY_RIGHT;
  config.communication_format = I2S_COMM_FORMAT_STAND_I2S;
  config.intr_alloc_flags = ESP_INTR_FLAG_LEVEL1;
  config.dma_buf_count = 6;
  config.dma_buf_len = 512;
  config.use_apll = false;
  config.tx_desc_auto_clear = false;
  config.fixed_mclk = 0;

  i2s_pin_config_t pins = {};
  pins.bck_io_num = MIC_SCK;
  pins.ws_io_num = MIC_WS;
  pins.data_out_num = I2S_PIN_NO_CHANGE;
  pins.data_in_num = MIC_SD;

  ESP_ERROR_CHECK(i2s_driver_install(MIC_I2S_PORT, &config, 0, nullptr));
  ESP_ERROR_CHECK(i2s_set_pin(MIC_I2S_PORT, &pins));
  ESP_ERROR_CHECK(i2s_zero_dma_buffer(MIC_I2S_PORT));
}

void setupSpeakerI2S() {
  i2s_config_t config = {};
  config.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX);
  config.sample_rate = SPK_SAMPLE_RATE;
  config.bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT;
  config.channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT;
  config.communication_format = I2S_COMM_FORMAT_STAND_I2S;
  config.intr_alloc_flags = ESP_INTR_FLAG_LEVEL1;
  config.dma_buf_count = 12;
  config.dma_buf_len = 1024;
  config.use_apll = false;
  config.tx_desc_auto_clear = true;
  config.fixed_mclk = 0;

  i2s_pin_config_t pins = {};
  pins.bck_io_num = SPK_BCLK;
  pins.ws_io_num = SPK_LRC;
  pins.data_out_num = SPK_DOUT;
  pins.data_in_num = I2S_PIN_NO_CHANGE;

  ESP_ERROR_CHECK(i2s_driver_install(SPK_I2S_PORT, &config, 0, nullptr));
  ESP_ERROR_CHECK(i2s_set_pin(SPK_I2S_PORT, &pins));
  ESP_ERROR_CHECK(i2s_zero_dma_buffer(SPK_I2S_PORT));
}
