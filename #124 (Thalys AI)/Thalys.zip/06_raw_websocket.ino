void resetWsFragmentBuffer() {
  if (wsFragmentBuffer) {
    free(wsFragmentBuffer);
    wsFragmentBuffer = nullptr;
  }
  wsFragmentLen = 0;
  wsFragmentExpectedLen = 0;
}

bool appendWsFragment(uint8_t *payload, size_t length) {
  if (length == 0) return true;
  if (wsFragmentLen + length > WS_FRAGMENT_MAX) {
    LOG_ERROR("WebSocket fragment buffer overflow; dropping message");
    resetWsFragmentBuffer();
    return false;
  }

  uint8_t *next = (uint8_t *)realloc(wsFragmentBuffer, wsFragmentLen + length);
  if (!next) {
    LOG_ERROR("WebSocket fragment realloc failed");
    resetWsFragmentBuffer();
    return false;
  }

  wsFragmentBuffer = next;
  memcpy(wsFragmentBuffer + wsFragmentLen, payload, length);
  wsFragmentLen += length;
  return true;
}

void handleWebSocketPayload(uint8_t *payload, size_t length) {
  if (!payload || length == 0) return;

  bool handledJson = false;
  for (size_t i = 0; i < length; i++) {
    if (payload[i] == '{') {
      if (length - i <= 512) {
        printPayload("WebSocket JSON", payload + i, length - i);
      }
      handleGeminiMessage(payload + i, length - i);
      handledJson = true;
      break;
    }
  }

  if (!handledJson) {
    enqueueRawAudioCopy(payload, length);
  }
}

bool sendWsFrame(uint8_t opcode, const uint8_t *payload, size_t length) {
  if (!wsConnected || !wsClient.connected()) return false;

  uint8_t header[14];
  size_t headerLen = 0;
  header[headerLen++] = 0x80 | (opcode & 0x0F);

  if (length < 126) {
    header[headerLen++] = 0x80 | (uint8_t)length;
  } else if (length <= 0xFFFF) {
    header[headerLen++] = 0x80 | 126;
    header[headerLen++] = (length >> 8) & 0xFF;
    header[headerLen++] = length & 0xFF;
  } else {
    header[headerLen++] = 0x80 | 127;
    uint64_t len64 = length;
    for (int i = 7; i >= 0; i--) {
      header[headerLen++] = (len64 >> (i * 8)) & 0xFF;
    }
  }

  uint8_t mask[4];
  for (int i = 0; i < 4; i++) mask[i] = (uint8_t)esp_random();
  memcpy(header + headerLen, mask, 4);
  headerLen += 4;

  if (wsClient.write(header, headerLen) != headerLen) return false;

  const size_t blockSize = 512;
  uint8_t block[blockSize];
  size_t offset = 0;
  while (offset < length) {
    size_t n = min(blockSize, length - offset);
    for (size_t i = 0; i < n; i++) {
      block[i] = payload[offset + i] ^ mask[(offset + i) & 3];
    }
    if (wsClient.write(block, n) != n) return false;
    offset += n;
  }

  return true;
}

bool sendWsText(const String &message) {
  return sendWsFrame(0x1, (const uint8_t *)message.c_str(), message.length());
}

bool readExact(uint8_t *dst, size_t length, uint32_t idleTimeoutMs = 15000) {
  uint32_t lastProgress = millis();
  size_t got = 0;
  while (got < length) {
    int available = wsClient.available();
    if (available > 0) {
      size_t want = min((size_t)available, length - got);
      int n = wsClient.read(dst + got, want);
      if (n > 0) {
        got += (size_t)n;
        lastProgress = millis();
      }
    } else {
      if (millis() - lastProgress > idleTimeoutMs) {
        if (SERIAL_LOG_LEVEL >= 1) {
          Serial.print("Raw WebSocket read timeout: got ");
          Serial.print((uint32_t)got);
          Serial.print(" of ");
          Serial.println((uint32_t)length);
        }
        return false;
      }
      delay(1);
    }
  }
  return true;
}

void serviceWebSocket() {
  if (!wsConnected || !wsClient.connected()) {
    if (wsConnected) {
      wsConnected = false;
      setupComplete = false;
      setupPending = false;
      geminiSessionActive = false;
      geminiSessionStreaming = false;
      geminiModelResponding = false;
      resetWsFragmentBuffer();
      statusLedOff();
      LOG_INFO("Raw WebSocket disconnected");
    }
    return;
  }

  while (wsClient.available() >= 2) {
    uint8_t hdr[2];
    if (!readExact(hdr, 2, 1000)) return;

    bool fin = hdr[0] & 0x80;
    uint8_t opcode = hdr[0] & 0x0F;
    bool masked = hdr[1] & 0x80;
    uint64_t payloadLen = hdr[1] & 0x7F;

    if (payloadLen == 126) {
      uint8_t ext[2];
      if (!readExact(ext, 2)) return;
      payloadLen = ((uint16_t)ext[0] << 8) | ext[1];
    } else if (payloadLen == 127) {
      uint8_t ext[8];
      if (!readExact(ext, 8)) return;
      payloadLen = 0;
      for (int i = 0; i < 8; i++) payloadLen = (payloadLen << 8) | ext[i];
    }

    if (payloadLen > 1024) {
      if (SERIAL_LOG_LEVEL >= 3) {
        Serial.print("Raw WebSocket frame opcode=");
        Serial.print(opcode);
        Serial.print(" fin=");
        Serial.print(fin ? "1" : "0");
        Serial.print(" len=");
        Serial.println((uint32_t)payloadLen);
      }
    }

    uint8_t mask[4] = {0, 0, 0, 0};
    if (masked && !readExact(mask, 4)) return;

    if (payloadLen > WS_FRAGMENT_MAX) {
      LOG_ERROR_KV("Raw WebSocket payload too large: ", (uint32_t)payloadLen);
      wsClient.stop();
      return;
    }

    uint8_t *payload = nullptr;
    if (payloadLen > 0) {
      payload = (uint8_t *)malloc(payloadLen);
      if (!payload) {
        LOG_ERROR("Raw WebSocket payload malloc failed");
        wsClient.stop();
        return;
      }
      if (!readExact(payload, payloadLen)) {
        free(payload);
        return;
      }
      if (masked) {
        for (uint64_t i = 0; i < payloadLen; i++) payload[i] ^= mask[i & 3];
      }
    }

    if (opcode == 0x8) {
      if (SERIAL_LOG_LEVEL >= 1) {
        Serial.print("Raw WebSocket close frame");
        if (payloadLen >= 2) {
          uint16_t code = ((uint16_t)payload[0] << 8) | payload[1];
          Serial.print(" code=");
          Serial.print(code);
        }
        if (payloadLen > 2) {
          Serial.print(" reason=");
          for (uint64_t i = 2; i < payloadLen; i++) Serial.write(payload[i]);
        }
        Serial.println();
      }
      free(payload);
      wsClient.stop();
      return;
    }

    if (opcode == 0x9) {
      sendWsFrame(0xA, payload, payloadLen);
      free(payload);
      continue;
    }

    if (opcode == 0x1 || opcode == 0x2) {
      if (fin) {
        handleWebSocketPayload(payload, payloadLen);
      } else {
        resetWsFragmentBuffer();
        appendWsFragment(payload, payloadLen);
      }
    } else if (opcode == 0x0) {
      appendWsFragment(payload, payloadLen);
      if (fin) {
        if (SERIAL_LOG_LEVEL >= 3) {
          Serial.print("Raw WebSocket fragmented payload complete: ");
          Serial.print(wsFragmentLen);
          Serial.println(" bytes");
        }
        handleWebSocketPayload(wsFragmentBuffer, wsFragmentLen);
        resetWsFragmentBuffer();
      }
    }

    free(payload);
  }
}

void connectWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  if (SERIAL_LOG_LEVEL >= 2) Serial.print("Connecting to Wi-Fi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
    if (SERIAL_LOG_LEVEL >= 2) Serial.print(".");
  }
  if (SERIAL_LOG_LEVEL >= 2) {
    Serial.println();
    Serial.print("Wi-Fi connected: ");
    Serial.println(WiFi.localIP());
  }
}

bool connectGemini() {
  String credential = GEMINI_API_KEY;
  String path;

  if (usingEphemeralToken) {
    LOG_INFO("Using Gemini Live v1alpha endpoint with ephemeral token.");
    path = "/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContentConstrained?access_token=";
    path += credential;
  } else {
    path = "/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent";
#if GEMINI_USE_QUERY_KEY
    LOG_INFO("Using Gemini Live v1beta endpoint with API key query parameter.");
    path += "?key=";
    path += credential;
#else
    LOG_INFO("Using Gemini Live v1beta endpoint with x-goog-api-key header.");
    geminiExtraHeaders = "x-goog-api-key: ";
    geminiExtraHeaders += credential;
#endif
  }

  LOG_INFO("Connecting to Gemini Live raw WebSocket...");
  wsClient.stop();
  wsClient.setInsecure();
  wsClient.setTimeout(10000);

  if (!wsClient.connect("generativelanguage.googleapis.com", 443)) {
    LOG_ERROR("Raw WebSocket TLS connect failed");
    return false;
  }

  String request;
  request += "GET ";
  request += path;
  request += " HTTP/1.1\r\n";
  request += "Host: generativelanguage.googleapis.com\r\n";
  request += "Upgrade: websocket\r\n";
  request += "Connection: Upgrade\r\n";
  request += "Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\n";
  request += "Sec-WebSocket-Version: 13\r\n";
#if !GEMINI_USE_QUERY_KEY
  request += geminiExtraHeaders;
  request += "\r\n";
#endif
  request += "\r\n";

  wsClient.print(request);

  String status = wsClient.readStringUntil('\n');
  status.trim();
  LOG_INFO_KV("Raw WebSocket handshake: ", status);

  bool ok = status.indexOf("101") >= 0;
  while (wsClient.connected()) {
    String line = wsClient.readStringUntil('\n');
    line.trim();
    if (line.length() == 0) break;
  }

  if (!ok) {
    LOG_ERROR("Raw WebSocket upgrade failed");
    wsClient.stop();
    return false;
  }

  wsConnected = true;
  setupComplete = false;
  setupPending = true;
  geminiSessionStreaming = false;
  geminiModelResponding = false;
  textAudioTestSent = false;
  setupReadyAtMs = millis() + 300;
  LOG_INFO("Raw WebSocket connected");
  return true;
}
