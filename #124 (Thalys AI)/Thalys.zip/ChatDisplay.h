#ifndef CHATDISPLAY_H
#define CHATDISPLAY_H

#include <Arduino.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7789.h>
#define ROBOT_W 25
#define ROBOT_H 23

const uint8_t robotFace[] PROGMEM = {
  0x00, 0x1C, 0x00, 0x00,
  0x00, 0x1C, 0x00, 0x00,
  0x7F, 0xFF, 0xFF, 0x00,
  0xFF, 0xFF, 0xFF, 0x80,
  0xC0, 0x00, 0x01, 0x80,
  0x80, 0x00, 0x00, 0x80,
  0x87, 0x83, 0xC0, 0x80,
  0x8F, 0xC7, 0xE0, 0x80,
  0x8F, 0xC7, 0xE0, 0x80,
  0x87, 0x83, 0xC0, 0x80,
  0x80, 0x00, 0x00, 0x80,
  0x80, 0x00, 0x00, 0x80,
  0x81, 0xFF, 0x80, 0x80,
  0x81, 0x00, 0x80, 0x80,
  0x81, 0xFF, 0x80, 0x80,
  0x80, 0x00, 0x00, 0x80,
  0x80, 0x00, 0x00, 0x80,
  0xC0, 0x00, 0x01, 0x80,
  0xFF, 0xFF, 0xFF, 0x80,
  0x7F, 0xFF, 0xFF, 0x00,
  0x00, 0xC0, 0xC0, 0x00,
  0x01, 0xC0, 0xE0, 0x00,
  0x01, 0xC0, 0xE0, 0x00,
};
//
// Configurazione
//
#define CHAT_MAX_LINES 11
#define CHAT_MAX_LINE_LENGTH 30
//Colori non presenti nella libreria GFX
#define ST77XX_GRAY 0x7BEF
//
// Tipologia messaggio
//
enum ChatType {
  CHAT_USER,
  CHAT_AI,
  CHAT_SYSTEM,
  CHAT_INFO,
  CHAT_ERROR
};

//
// Riga già pronta per il rendering
//
struct ChatLine {
  char text[CHAT_MAX_LINE_LENGTH];
  uint16_t color;
  bool rightAlign;
};

class ChatDisplay {
public:

  //--------------------------------------------------
  // Costruttore
  //--------------------------------------------------
  ChatDisplay(Adafruit_ST7789 &display);

  //--------------------------------------------------
  // Inizializzazione
  //--------------------------------------------------
  void begin(const char *title = "IoComeLoFaccio-AI");

  //--------------------------------------------------
  // Cancella cronologia
  //--------------------------------------------------
  void clear();

  //--------------------------------------------------
  // Cambia titolo
  //--------------------------------------------------
  void setTitle(const char *title);

  //--------------------------------------------------
  // Messaggi
  //--------------------------------------------------
  void user(const char *text);

  void ai(const char *text);

  void system(const char *text);

  void info(const char *text);

  void error(const char *text);

  //--------------------------------------------------
  // Ridisegna
  //--------------------------------------------------
  void refreshChat();
  void refreshHeader();

private:

  //--------------------------------------------------
  // Display
  //--------------------------------------------------
  Adafruit_ST7789 &_tft;

  //
  // 
  //
  GFXcanvas16 *_canvas;
  const GFXfont *_chatFont;
  const GFXfont *_headerFont;
  //--------------------------------------------------
  // Dimensioni display
  //--------------------------------------------------
  uint16_t _width;
  uint16_t _height;

  //--------------------------------------------------
  // Layout
  //--------------------------------------------------
  uint16_t _headerHeight;
  uint16_t _lineHeight;
  uint16_t _margin;
  int16_t _chatBaseline;

  //--------------------------------------------------
  // Colori
  //--------------------------------------------------
  uint16_t _backgroundColor;
  uint16_t _headerColor;
  uint16_t _headerTextColor;

  uint16_t _userColor;
  uint16_t _aiColor;
  uint16_t _systemColor;
  uint16_t _infoColor;
  uint16_t _errorColor;

  //--------------------------------------------------
  // Header
  //--------------------------------------------------
  char _title[32];

  //--------------------------------------------------
  // Buffer circolare
  //--------------------------------------------------
  ChatLine _history[CHAT_MAX_LINES];

  uint16_t _head;
  uint16_t _count;

  //--------------------------------------------------
  // Funzioni interne
  //--------------------------------------------------

  void addMessage(const char *text, uint16_t color, bool align);

  void wrapText(const char *text, uint16_t color, bool align);

  void pushLine(const char *text, uint16_t color, bool align);

  void drawHeader();

  void drawChat();

  uint16_t visibleLines() const;

  uint16_t textWidth(const char *text);
};

#endif
