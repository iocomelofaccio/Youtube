#include <Arduino.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7789.h>
#include <ArduinoJson.h>
#include <ctype.h>
#include "driver/i2s.h"
#include "mbedtls/base64.h"
#include "ChatDisplay.h"


#if __has_include("parameters.h")
#include "parameters.h"
#endif

#ifndef WIFI_SSID
#define WIFI_SSID "YOUR_WIFI_SSID"
#endif

#ifndef WIFI_PASSWORD
#define WIFI_PASSWORD "YOUR_WIFI_PASSWORD"
#endif

#ifndef GEMINI_API_KEY
#define GEMINI_API_KEY "YOUR_GEMINI_API_KEY"
#endif

#ifndef GEMINI_USE_EPHEMERAL_TOKEN
#define GEMINI_USE_EPHEMERAL_TOKEN 0
#endif

#ifndef GEMINI_USE_QUERY_KEY
#define GEMINI_USE_QUERY_KEY 1
#endif

#ifndef GEMINI_SEND_SYSTEM_INSTRUCTION
#define GEMINI_SEND_SYSTEM_INSTRUCTION 1
#endif

#ifndef GEMINI_SYSTEM_PROMPT
#define GEMINI_SYSTEM_PROMPT "Il tuo nome e Thalys sei un assistente vocale in italiano. Io sono Emanuele ed ho un canale Youtube che si chiama IoComeLoFaccio. Rispondi in modo breve, naturale e utile."
#endif

#ifndef GEMINI_USE_SPEECH_CONFIG
#define GEMINI_USE_SPEECH_CONFIG 1
#endif

#ifndef GEMINI_TEXT_AUDIO_TEST_ON_SETUP
#define GEMINI_TEXT_AUDIO_TEST_ON_SETUP 0
#endif

#ifndef GEMINI_MINIMAL_AUDIO_SETUP
#define GEMINI_MINIMAL_AUDIO_SETUP 0
#endif

#ifndef GEMINI_ENABLE_TRANSCRIPTIONS
#define GEMINI_ENABLE_TRANSCRIPTIONS 1
#endif

#ifndef TRANSCRIPT_HISTORY_MAX
#define TRANSCRIPT_HISTORY_MAX 20
#endif

#ifndef SERIAL_LOG_LEVEL
#define SERIAL_LOG_LEVEL 1
#endif

// 0=silent, 1=errors, 2=status, 3=verbose debug.
#define LOG_ERROR(msg) \
  do { \
    if (SERIAL_LOG_LEVEL >= 1) Serial.println(msg); \
  } while (0)
#define LOG_INFO(msg) \
  do { \
    if (SERIAL_LOG_LEVEL >= 2) Serial.println(msg); \
  } while (0)
#define LOG_DEBUG(msg) \
  do { \
    if (SERIAL_LOG_LEVEL >= 3) Serial.println(msg); \
  } while (0)
#define LOG_ERROR_KV(label, value) \
  do { \
    if (SERIAL_LOG_LEVEL >= 1) { \
      Serial.print(label); \
      Serial.println(value); \
    } \
  } while (0)
#define LOG_INFO_KV(label, value) \
  do { \
    if (SERIAL_LOG_LEVEL >= 2) { \
      Serial.print(label); \
      Serial.println(value); \
    } \
  } while (0)
#define LOG_DEBUG_KV(label, value) \
  do { \
    if (SERIAL_LOG_LEVEL >= 3) { \
      Serial.print(label); \
      Serial.println(value); \
    } \
  } while (0)

#ifndef GEMINI_USE_MANUAL_PTT
#define GEMINI_USE_MANUAL_PTT 1
#endif

#ifndef GEMINI_SESSION_TOGGLE_MODE
#define GEMINI_SESSION_TOGGLE_MODE 1
#endif

#ifndef GEMINI_VOICE_NAME
#define GEMINI_VOICE_NAME "Aoede"
#endif

#ifndef SPEAKER_TEST_TONE_ON_BOOT
#define SPEAKER_TEST_TONE_ON_BOOT 0
#endif

#ifndef SPEAKER_VOLUME_PERCENT
#define SPEAKER_VOLUME_PERCENT 70
#endif

#ifndef SPEAKER_JITTER_BUFFER_CHUNKS
#define SPEAKER_JITTER_BUFFER_CHUNKS 3
#endif

#ifndef SPEAKER_JITTER_BUFFER_MS
#define SPEAKER_JITTER_BUFFER_MS 150
#endif

#ifndef PTT_PIN
#define PTT_PIN 8
#endif

#ifndef PTT_ACTIVE_LOW
#define PTT_ACTIVE_LOW 1
#endif

#ifndef PTT_USE_INTERNAL_PULLUP
#define PTT_USE_INTERNAL_PULLUP 1
#endif

// Safety net for boards where BOOT/GPIO0 reads as permanently pressed.
#ifndef PTT_MAX_HOLD_MS
#define PTT_MAX_HOLD_MS 4500
#endif

#ifndef STATUS_RGB_LED_ENABLED
#define STATUS_RGB_LED_ENABLED 1
#endif

#ifndef STATUS_RGB_LED_PIN
#define STATUS_RGB_LED_PIN 48
#endif

#ifndef STATUS_RGB_LED_BRIGHTNESS
#define STATUS_RGB_LED_BRIGHTNESS 32
#endif

#ifndef TFT_ENABLED
#define TFT_ENABLED 1
#endif

#ifndef TFT_CS
#define TFT_CS 41
#endif

#ifndef TFT_RST
#define TFT_RST 45
#endif

#ifndef TFT_DC
#define TFT_DC 40
#endif

#ifndef TFT_MOSI
#define TFT_MOSI 47
#endif

#ifndef TFT_SCLK
#define TFT_SCLK 21
#endif

#ifndef TFT_BL
#define TFT_BL 42
#endif

#ifndef TFT_WIDTH
#define TFT_WIDTH 240
#endif

#ifndef TFT_HEIGHT
#define TFT_HEIGHT 240
#endif

#ifndef TFT_ROTATION
#define TFT_ROTATION 2
#endif

#ifndef GEMINI_MODEL_NAME
#define GEMINI_MODEL_NAME "gemini-2.5-flash-native-audio-latest"
#endif

// Gemini Live model. If Google changes preview model names, update this value.
const char *GEMINI_MODEL = GEMINI_MODEL_NAME;
// INMP441 - I2S RX
#define MIC_I2S_PORT I2S_NUM_0
#define MIC_WS 4
#define MIC_SCK 5
#define MIC_SD 6

// INMP441 L/R tied to GND usually means left channel. Set to 0 if your module is wired for right.
#ifndef MIC_CHANNEL_LEFT
#define MIC_CHANNEL_LEFT 1
#endif

// Software gain applied after converting INMP441 24-bit samples to int16.
// 0 = no gain, 3 = x8, 4 = x16. Start with 4 if avgAbs is under ~200 while speaking.
#ifndef MIC_GAIN_SHIFT
#define MIC_GAIN_SHIFT 4
#endif

#ifndef LOCAL_VAD_START_AVG
#define LOCAL_VAD_START_AVG 550
#endif

#ifndef LOCAL_VAD_START_MAX
#define LOCAL_VAD_START_MAX 3500
#endif

#ifndef LOCAL_VAD_STOP_AVG
#define LOCAL_VAD_STOP_AVG 260
#endif

#ifndef LOCAL_VAD_SILENCE_MS
#define LOCAL_VAD_SILENCE_MS 1200
#endif

#ifndef LOCAL_VAD_MAX_TURN_MS
#define LOCAL_VAD_MAX_TURN_MS 12000
#endif

// MAX98357A - I2S TX
#define SPK_I2S_PORT I2S_NUM_1
#define SPK_BCLK 15
#define SPK_LRC 16
#define SPK_DOUT 7

// Gemini Live audio formats.
static const int MIC_SAMPLE_RATE = 16000;
static const int SPK_SAMPLE_RATE = 24000;
static const size_t WS_FRAGMENT_MAX = 131072;

// 100 ms of 16 kHz mono audio. Small enough for latency, large enough for JSON overhead.
static const size_t MIC_SAMPLES_PER_CHUNK = 1600;
static int32_t micRaw[MIC_SAMPLES_PER_CHUNK];
static int16_t micPcm16[MIC_SAMPLES_PER_CHUNK];

struct AudioChunk {
  uint8_t *data;
  size_t len;
};

WiFiClientSecure wsClient;
#if TFT_ENABLED
//Adafruit_ST7789 tft(TFT_CS, TFT_DC, TFT_MOSI, TFT_SCLK, TFT_RST);
Adafruit_ST7789 tft = Adafruit_ST7789(TFT_CS, TFT_DC, TFT_MOSI, TFT_SCLK, TFT_RST);
ChatDisplay chat(tft);
#endif
volatile bool wsConnected = false;
volatile bool setupComplete = false;
bool wasPttPressed = false;
bool usingEphemeralToken = GEMINI_USE_EPHEMERAL_TOKEN;
bool setupPending = false;
bool textAudioTestSent = false;
bool geminiSessionActive = false;
bool geminiSessionStreaming = false;
bool geminiModelResponding = false;
bool localVadSpeechActive = false;
uint32_t setupReadyAtMs = 0;
uint32_t lastMicLogAtMs = 0;
uint32_t lastPttLogAtMs = 0;
uint32_t pttStartedAtMs = 0;
uint32_t lastSessionToggleAtMs = 0;
uint32_t lastLocalSpeechAtMs = 0;
uint32_t localVadTurnStartedAtMs = 0;
uint32_t localVadSilenceStartedAtMs = 0;
uint32_t audioChunksSent = 0;
int lastPttRaw = -1;
bool pttLockedUntilRelease = false;
String geminiExtraHeaders;
String pendingUserTranscript;
String pendingAiTranscript;
bool transcriptCommitScheduled = false;
uint32_t lastTranscriptUpdateAtMs = 0;
String userTranscript[TRANSCRIPT_HISTORY_MAX];
String aiTranscript[TRANSCRIPT_HISTORY_MAX];
uint8_t userTranscriptCount = 0;
uint8_t aiTranscriptCount = 0;
QueueHandle_t speakerQueue = nullptr;
DynamicJsonDocument geminiDoc(98304);
uint8_t *wsFragmentBuffer = nullptr;
size_t wsFragmentLen = 0;
size_t wsFragmentExpectedLen = 0;

void setupDisplay();
void setupMicI2S();
void setupSpeakerI2S();
void playTestTone(uint16_t freqHz, uint16_t durationMs);
void speakerTask(void *param);
void connectWiFi();
bool connectGemini();
void serviceWebSocket();
void sendGeminiSetup();
void commitStaleTranscripts();
void handleSessionToggleButton();
void setupStatusLed();
void statusLedOff();
void statusLedListening();
void statusLedSpeaking();
void streamMic();
void streamMicIfPressed();
void streamMicWithLocalVad();


// Implementation is split across numbered .ino tabs for readability.

void setup() {
  Serial.begin(115200);
  uint32_t serialStart = millis();
  while (!Serial && millis() - serialStart < 3000) {
    delay(10);
  }
  delay(300);

  LOG_INFO("");
  LOG_INFO("=== Gemini ESP32-S3 raw websocket boot ===");
  LOG_INFO_KV("Gemini model: ", GEMINI_MODEL);
  LOG_INFO("WebSocket transport: raw WiFiClientSecure");
  setupStatusLed();
  setupDisplay();
  chat.begin();

  chat.info("Schermo OK");
  delay(500);
  chat.info("Seriale OK");
  delay(500);

#if GEMINI_USE_MANUAL_PTT || GEMINI_SESSION_TOGGLE_MODE
#if PTT_USE_INTERNAL_PULLUP
  pinMode(PTT_PIN, INPUT_PULLUP);
#else
  pinMode(PTT_PIN, INPUT);
#endif
  lastPttRaw = digitalRead(PTT_PIN);
  wasPttPressed = false;
  LOG_INFO_KV("PTT pin: ", PTT_PIN);
  LOG_INFO_KV("PTT initial raw: ", lastPttRaw);
  chat.info("Pulsante OK");
  delay(500);
#endif

  LOG_INFO("Starting I2S mic...");
  setupMicI2S();
  chat.info("Microfono OK");
  delay(500);
  LOG_INFO("Starting I2S speaker...");
  setupSpeakerI2S();
  chat.info("Speaker OK");
  delay(500);
#if SPEAKER_TEST_TONE_ON_BOOT
  LOG_INFO("Playing speaker test tone: 3 loud beeps");
  playTestTone(440, 350);
  delay(150);
  playTestTone(660, 350);
  delay(150);
  playTestTone(880, 350);
  LOG_INFO("Speaker test tone done");
#endif
  speakerQueue = xQueueCreate(128, sizeof(AudioChunk));
  xTaskCreatePinnedToCore(speakerTask, "speakerTask", 8192, nullptr, 2, nullptr, 1);
  LOG_INFO("Audio tasks ready");
  connectWiFi();
  chat.info("WiFi OK");
  delay(500);
#if GEMINI_SESSION_TOGGLE_MODE
  chat.info("Premi per parlare...");
  LOG_INFO("Gemini socket idle. Press and release PTT to start listening; press and release again to disconnect.");
#else
  if (connectGemini()) {
    chat.info("Gemini OK");
  } else {
    chat.error("Gemini KO");
  }
  delay(500);
  LOG_INFO(GEMINI_USE_MANUAL_PTT ? "Hold PTT to stream audio to Gemini." : "Automatic VAD mode: streaming mic continuously.");
#endif
}

void loop() {
  serviceWebSocket();
  commitStaleTranscripts();
  if (setupPending && wsConnected && millis() >= setupReadyAtMs) {
    setupPending = false;
    sendGeminiSetup();
  }
  if (GEMINI_SESSION_TOGGLE_MODE) {
    handleSessionToggleButton();
    if (geminiSessionActive && wsConnected && setupComplete && !geminiModelResponding) {
      if (!geminiSessionStreaming) {
        geminiSessionStreaming = true;
        LOG_INFO("Gemini listening with local VAD");
        chat.setTitle("Ascolto ON");
        statusLedListening();
      }
      streamMicWithLocalVad();
    } else if (geminiModelResponding) {
      if (geminiSessionStreaming) {
        chat.setTitle("Rispondo...");
      }
      geminiSessionStreaming = false;
      statusLedSpeaking();
    }
  } else if (GEMINI_USE_MANUAL_PTT) {
    streamMicIfPressed();
  } else {
    streamMic();
  }
}
