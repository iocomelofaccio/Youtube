bool readMicChunk(uint32_t *avgAbsOut, uint32_t *maxAbsOut, size_t *samplesReadOut) {
  size_t bytesRead = 0;
  esp_err_t err = i2s_read(MIC_I2S_PORT, micRaw, sizeof(micRaw), &bytesRead, pdMS_TO_TICKS(200));
  if (err != ESP_OK || bytesRead == 0) return false;

  size_t samplesRead = bytesRead / sizeof(int32_t);
  uint64_t absSum = 0;
  uint32_t maxAbs = 0;
  for (size_t i = 0; i < samplesRead; i++) {
    // INMP441 usually provides 24-bit audio left-aligned in a 32-bit slot.
    int32_t sample24 = micRaw[i] >> 8;
    sample24 = constrain(sample24, -8388608, 8388607);
    int32_t sample16 = sample24 >> 8;
    sample16 <<= MIC_GAIN_SHIFT;
    sample16 = constrain(sample16, -32768, 32767);
    micPcm16[i] = (int16_t)sample16;

    uint32_t a = abs((int)micPcm16[i]);
    absSum += a;
    if (a > maxAbs) maxAbs = a;
  }

  uint32_t avgAbs = samplesRead ? absSum / samplesRead : 0;
  if (avgAbsOut) *avgAbsOut = avgAbs;
  if (maxAbsOut) *maxAbsOut = maxAbs;
  if (samplesReadOut) *samplesReadOut = samplesRead;
  uint32_t now = millis();
  if (now - lastMicLogAtMs > 1000) {
    lastMicLogAtMs = now;
    if (SERIAL_LOG_LEVEL >= 3) {
      Serial.print("Mic avgAbs=");
      Serial.print(avgAbs);
      Serial.print(" maxAbs=");
      Serial.print(maxAbs);
      Serial.print(" chunksSent=");
      Serial.println(audioChunksSent);
    }
  }

  return true;
}

void streamMic() {
  size_t samplesRead = 0;
  if (!readMicChunk(nullptr, nullptr, &samplesRead)) return;
  sendAudioChunk(micPcm16, samplesRead);
}

void streamMicWithLocalVad() {
  uint32_t avgAbs = 0;
  uint32_t maxAbs = 0;
  size_t samplesRead = 0;
  if (!readMicChunk(&avgAbs, &maxAbs, &samplesRead)) return;

  uint32_t now = millis();
  bool speechDetected = avgAbs >= LOCAL_VAD_START_AVG || maxAbs >= LOCAL_VAD_START_MAX;
  bool silenceDetected = avgAbs <= LOCAL_VAD_STOP_AVG;

  if (!localVadSpeechActive && speechDetected) {
    lastLocalSpeechAtMs = now;
    localVadTurnStartedAtMs = now;
    localVadSilenceStartedAtMs = 0;
    localVadSpeechActive = true;
    clearPendingTranscripts();
    sendWsText("{\"realtimeInput\":{\"activityStart\":{}}}");
    LOG_INFO("Local VAD speech start");
    chat.setTitle("Ti ascolto...");
  }

  if (localVadSpeechActive) {
    sendAudioChunk(micPcm16, samplesRead);

    if (silenceDetected) {
      if (localVadSilenceStartedAtMs == 0) localVadSilenceStartedAtMs = now;
    } else {
      lastLocalSpeechAtMs = now;
      localVadSilenceStartedAtMs = 0;
    }

    bool silenceLongEnough = localVadSilenceStartedAtMs > 0 && now - localVadSilenceStartedAtMs >= LOCAL_VAD_SILENCE_MS;
    bool turnTooLong = LOCAL_VAD_MAX_TURN_MS > 0 && localVadTurnStartedAtMs > 0 && now - localVadTurnStartedAtMs >= LOCAL_VAD_MAX_TURN_MS;

    if (silenceLongEnough || turnTooLong) {
      localVadSpeechActive = false;
      localVadTurnStartedAtMs = 0;
      localVadSilenceStartedAtMs = 0;
      sendWsText("{\"realtimeInput\":{\"activityEnd\":{}}}");
      LOG_INFO(silenceLongEnough ? "Local VAD silence end" : "Local VAD max turn end");
      chat.setTitle("Rispondo...");
    }
  }
}

void streamMicIfPressed() {
  bool pressed = isPttPressed();
  uint32_t now = millis();

  if (now - lastPttLogAtMs > 1000) {
    lastPttLogAtMs = now;
    if (SERIAL_LOG_LEVEL >= 3) {
      Serial.print("PTT raw=");
      Serial.print(digitalRead(PTT_PIN));
      Serial.print(" pressed=");
      Serial.print(pressed ? "yes" : "no");
      Serial.print(" locked=");
      Serial.println(pttLockedUntilRelease ? "yes" : "no");
    }
  }

  if (!pressed && pttLockedUntilRelease) {
    pttLockedUntilRelease = false;
    LOG_INFO("PTT lock cleared");
  }

  if (pttLockedUntilRelease) return;

  if (pressed && !wasPttPressed) {
    wasPttPressed = true;
    pttStartedAtMs = now;
    sendActivityStart();
  }

  if (!pressed && wasPttPressed) {
    wasPttPressed = false;
    sendActivityEnd();
    return;
  }

  if (!pressed) return;

  if (PTT_MAX_HOLD_MS > 0 && pttStartedAtMs > 0 && now - pttStartedAtMs > PTT_MAX_HOLD_MS) {
    LOG_INFO("PTT max hold reached; forcing activityEnd");
    wasPttPressed = false;
    pttLockedUntilRelease = true;
    sendActivityEnd();
    return;
  }

  streamMic();
}
