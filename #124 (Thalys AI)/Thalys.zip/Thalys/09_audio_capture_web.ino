uint8_t *audioCaptureBuffer = nullptr;
size_t audioCaptureCapacity = 0;
size_t audioCaptureLength = 0;
bool audioCaptureActive = false;
bool audioCaptureOverflow = false;

void writeWavHeader(uint8_t *header, uint32_t dataSize) {
  uint32_t riffSize = dataSize + 36;
  uint32_t byteRate = MIC_SAMPLE_RATE * 2;
  uint16_t blockAlign = 2;
  uint16_t bitsPerSample = 16;

  memcpy(header + 0, "RIFF", 4);
  header[4] = riffSize & 0xff;
  header[5] = (riffSize >> 8) & 0xff;
  header[6] = (riffSize >> 16) & 0xff;
  header[7] = (riffSize >> 24) & 0xff;
  memcpy(header + 8, "WAVE", 4);
  memcpy(header + 12, "fmt ", 4);
  header[16] = 16;
  header[17] = 0;
  header[18] = 0;
  header[19] = 0;
  header[20] = 1;
  header[21] = 0;
  header[22] = 1;
  header[23] = 0;
  header[24] = MIC_SAMPLE_RATE & 0xff;
  header[25] = (MIC_SAMPLE_RATE >> 8) & 0xff;
  header[26] = (MIC_SAMPLE_RATE >> 16) & 0xff;
  header[27] = (MIC_SAMPLE_RATE >> 24) & 0xff;
  header[28] = byteRate & 0xff;
  header[29] = (byteRate >> 8) & 0xff;
  header[30] = (byteRate >> 16) & 0xff;
  header[31] = (byteRate >> 24) & 0xff;
  header[32] = blockAlign & 0xff;
  header[33] = (blockAlign >> 8) & 0xff;
  header[34] = bitsPerSample & 0xff;
  header[35] = (bitsPerSample >> 8) & 0xff;
  memcpy(header + 36, "data", 4);
  header[40] = dataSize & 0xff;
  header[41] = (dataSize >> 8) & 0xff;
  header[42] = (dataSize >> 16) & 0xff;
  header[43] = (dataSize >> 24) & 0xff;
}

String htmlEscape(const String &text) {
  String out;
  out.reserve(text.length());
  for (size_t i = 0; i < text.length(); i++) {
    char c = text[i];
    if (c == '&') out += "&amp;";
    else if (c == '<') out += "&lt;";
    else if (c == '>') out += "&gt;";
    else if (c == '"') out += "&quot;";
    else if (c == '\'') out += "&#39;";
    else out += c;
  }
  return out;
}

void appendChatBubble(String &html, const char *role, const String &text, bool user) {
  if (text.length() == 0) return;

  html += "<div class='row ";
  html += (user ? "me" : "ai");
  html += "'><div class='bubble'><div class='role'>";
  html += role;
  html += "</div>";
  html += htmlEscape(text);
  html += "</div></div>";
}

void appendTranscriptChat(String &html) {
  uint8_t maxCount = max(userTranscriptCount, aiTranscriptCount);
  html += "<section><h2>Conversazione</h2>";

  if (maxCount == 0) {
    html += "<p class='muted'>Nessuna trascrizione disponibile.</p>";
    html += "</section>";
    return;
  }

  html += "<div class='chat'>";
  for (uint8_t i = 0; i < maxCount; i++) {
    if (i < userTranscriptCount) appendChatBubble(html, "Emanuele", userTranscript[i], true);
    if (i < aiTranscriptCount) appendChatBubble(html, "Thalys", aiTranscript[i], false);
  }
  html += "</div></section>";
}

void handleAudioCaptureIndex() {
  String html;
  html.reserve(3200);
  html += "<!doctype html><html><head><meta charset='utf-8'>";
  html += "<meta name='viewport' content='width=device-width,initial-scale=1'>";
  html += "<title>Thalys audio debug</title>";
  html += "<style>body{font-family:system-ui,sans-serif;margin:24px;line-height:1.45;background:#f6f7f9;color:#15171a}";
  html += "main{max-width:760px;margin:0 auto}section{margin:22px 0}";
  html += "a.button{display:inline-block;background:#111;color:white;padding:10px 14px;border-radius:6px;text-decoration:none}";
  html += ".muted{color:#69707a}.chat{display:flex;flex-direction:column;gap:10px}";
  html += ".row{display:flex}.row.me{justify-content:flex-end}.row.ai{justify-content:flex-start}";
  html += ".bubble{max-width:82%;padding:10px 12px;border-radius:10px;box-shadow:0 1px 2px rgba(0,0,0,.08);white-space:pre-wrap;overflow-wrap:anywhere}";
  html += ".me .bubble{background:#dff3ff;border-bottom-right-radius:3px}.ai .bubble{background:#fff;border-bottom-left-radius:3px}";
  html += ".role{font-size:12px;font-weight:700;margin-bottom:3px;color:#4c5661}</style></head><body><main>";
  html += "<h1>Thalys audio debug</h1>";

  html += "<section><h2>Ultima acquisizione audio</h2>";
  if (!cfg.audioCaptureDebugEnabled) {
    html += "<p>Debug acquisizione audio disabilitato.</p>";
  } else if (audioCaptureActive) {
    html += "<p>Registrazione in corso...</p>";
  } else if (audioCaptureLength > 0) {
    uint32_t durationMs = (audioCaptureLength / 2UL) * 1000UL / MIC_SAMPLE_RATE;
    html += "<p>Ultima acquisizione: ";
    html += String(audioCaptureLength);
    html += " byte, circa ";
    html += String(durationMs);
    html += " ms";
    if (audioCaptureOverflow) html += " <span class='muted'>(tagliata al limite massimo)</span>";
    html += ".</p>";
    html += "<p><a class='button' href='/last_capture.wav'>Scarica WAV</a></p>";
  } else {
    html += "<p>Nessuna acquisizione audio disponibile.</p>";
  }
  html += "<p class='muted'>Formato: PCM 16 bit mono, 16000 Hz.</p>";
  html += "</section>";

  appendTranscriptChat(html);
  html += "<section><p><a href='/config'>Configura parametri</a></p></section>";
  html += "</main></body></html>";
  audioCaptureServer.send(200, "text/html; charset=utf-8", html);
}

void handleAudioCaptureDownload() {
  if (!cfg.audioCaptureDebugEnabled) {
    audioCaptureServer.send(404, "text/plain; charset=utf-8", "Debug acquisizione audio disabilitato.");
    return;
  }

  if (audioCaptureActive) {
    audioCaptureServer.send(409, "text/plain; charset=utf-8", "Registrazione in corso, riprova tra poco.");
    return;
  }

  if (!audioCaptureBuffer || audioCaptureLength == 0) {
    audioCaptureServer.send(404, "text/plain; charset=utf-8", "Nessuna acquisizione audio disponibile.");
    return;
  }

  uint8_t header[44] = {0};
  writeWavHeader(header, audioCaptureLength);

  audioCaptureServer.sendHeader("Content-Disposition", "attachment; filename=\"thalys_last_capture.wav\"");
  audioCaptureServer.setContentLength(44 + audioCaptureLength);
  audioCaptureServer.send(200, "audio/wav", "");

  WiFiClient client = audioCaptureServer.client();
  client.write(header, sizeof(header));
  client.write(audioCaptureBuffer, audioCaptureLength);
}

void configureAudioCaptureBuffer() {
  audioCaptureActive = false;
  if (audioCaptureBuffer) {
    free(audioCaptureBuffer);
    audioCaptureBuffer = nullptr;
  }
  audioCaptureCapacity = 0;
  audioCaptureLength = 0;
  audioCaptureOverflow = false;

  if (!cfg.audioCaptureDebugEnabled) return;

  if (cfg.audioCaptureDebugEnabled) {
    audioCaptureCapacity = (size_t)cfg.audioCaptureMaxSeconds * MIC_SAMPLE_RATE * sizeof(int16_t);
  }

  if (cfg.audioCaptureDebugEnabled && audioCaptureCapacity == 0) {
    LOG_ERROR("Audio capture disabled: zero capacity");
    cfg.audioCaptureDebugEnabled = false;
    return;
  }

  if (cfg.audioCaptureDebugEnabled && psramFound()) {
    audioCaptureBuffer = (uint8_t *)ps_malloc(audioCaptureCapacity);
  }
  if (cfg.audioCaptureDebugEnabled && !audioCaptureBuffer) {
    audioCaptureBuffer = (uint8_t *)malloc(audioCaptureCapacity);
  }

  if (cfg.audioCaptureDebugEnabled && !audioCaptureBuffer) {
    LOG_ERROR("Audio capture buffer allocation failed");
    cfg.audioCaptureDebugEnabled = false;
  }
}

void setupAudioCaptureWeb() {
  configureAudioCaptureBuffer();
  audioCaptureServer.on("/", HTTP_GET, handleAudioCaptureIndex);
  audioCaptureServer.on("/last_capture.wav", HTTP_GET, handleAudioCaptureDownload);
  setupConfigWebRoutes();
  audioCaptureServer.begin();
  LOG_INFO_KV("Audio capture web server ready on port ", AUDIO_CAPTURE_WEB_PORT);
}

void serviceAudioCaptureWeb() {
  audioCaptureServer.handleClient();
}

void audioCaptureBegin() {
  if (!cfg.audioCaptureDebugEnabled) return;
  if (!audioCaptureBuffer) return;
  audioCaptureLength = 0;
  audioCaptureOverflow = false;
  audioCaptureActive = true;
  LOG_DEBUG("Audio capture begin");
}

void audioCaptureAppend(const int16_t *samples, size_t sampleCount) {
  if (!cfg.audioCaptureDebugEnabled) return;
  if (!audioCaptureActive || !audioCaptureBuffer || !samples || sampleCount == 0) return;

  size_t bytes = sampleCount * sizeof(int16_t);
  size_t room = audioCaptureCapacity - audioCaptureLength;
  if (bytes > room) {
    bytes = room;
    audioCaptureOverflow = true;
  }

  if (bytes > 0) {
    memcpy(audioCaptureBuffer + audioCaptureLength, samples, bytes);
    audioCaptureLength += bytes;
  }
}

void audioCaptureEnd() {
  if (!cfg.audioCaptureDebugEnabled) return;
  if (!audioCaptureActive) return;
  audioCaptureActive = false;
  LOG_INFO_KV("Audio capture bytes: ", audioCaptureLength);
}
