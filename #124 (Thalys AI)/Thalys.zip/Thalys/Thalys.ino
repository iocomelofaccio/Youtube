#include <Arduino.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <WiFiManager.h>
#include <WebServer.h>
#include <ArduinoOTA.h>
#include <LittleFS.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7789.h>
#include <ArduinoJson.h>
#include <ctype.h>
#include "driver/i2s.h"
#include "mbedtls/base64.h"
#include "ChatDisplay.h"


#if __has_include("parameters.h")
#include "parameters.h"
#endif

#ifndef CONFIG_WEB_USERNAME
#define CONFIG_WEB_USERNAME "admin"
#endif

#ifndef CONFIG_WEB_PASSWORD
#define CONFIG_WEB_PASSWORD "thalys"
#endif

struct RuntimeConfig {
  String configWebUsername = CONFIG_WEB_USERNAME;
  String configWebPassword = CONFIG_WEB_PASSWORD;
  uint8_t serialLogLevel = SERIAL_LOG_LEVEL;
  String geminiApiKey = GEMINI_API_KEY;
  String geminiModelName = GEMINI_MODEL_NAME;
  bool geminiUseEphemeralToken = GEMINI_USE_EPHEMERAL_TOKEN;
  bool geminiUseQueryKey = GEMINI_USE_QUERY_KEY;
  String geminiSystemPrompt = GEMINI_SYSTEM_PROMPT;
  String geminiVoiceName = GEMINI_VOICE_NAME;
  bool geminiSendTranscriptContext = GEMINI_SEND_TRANSCRIPT_CONTEXT;
  uint8_t geminiContextTurns = GEMINI_CONTEXT_TURNS;
  bool audioCaptureDebugEnabled = AUDIO_CAPTURE_DEBUG_ENABLED;
  uint16_t audioCaptureMaxSeconds = AUDIO_CAPTURE_MAX_SECONDS;
  uint8_t speakerVolumePercent = SPEAKER_VOLUME_PERCENT;
  uint8_t tftBacklightBrightness = TFT_BL_BRIGHTNESS;
  uint8_t statusLedBrightness = STATUS_RGB_LED_BRIGHTNESS;
  uint8_t micGainShift = MIC_GAIN_SHIFT;
  uint16_t localVadStartAvg = LOCAL_VAD_START_AVG;
  uint16_t localVadStartMax = LOCAL_VAD_START_MAX;
  uint16_t localVadStopAvg = LOCAL_VAD_STOP_AVG;
  uint16_t localVadSilenceMs = LOCAL_VAD_SILENCE_MS;
  uint16_t localVadMaxTurnMs = LOCAL_VAD_MAX_TURN_MS;
};

RuntimeConfig cfg;

// 0=silent, 1=errors, 2=status, 3=verbose debug.
#define LOG_ERROR(msg) \
  do { \
    if (cfg.serialLogLevel >= 1) Serial.println(msg); \
  } while (0)
#define LOG_INFO(msg) \
  do { \
    if (cfg.serialLogLevel >= 2) Serial.println(msg); \
  } while (0)
#define LOG_DEBUG(msg) \
  do { \
    if (cfg.serialLogLevel >= 3) Serial.println(msg); \
  } while (0)
#define LOG_ERROR_KV(label, value) \
  do { \
    if (cfg.serialLogLevel >= 1) { \
      Serial.print(label); \
      Serial.println(value); \
    } \
  } while (0)
#define LOG_INFO_KV(label, value) \
  do { \
    if (cfg.serialLogLevel >= 2) { \
      Serial.print(label); \
      Serial.println(value); \
    } \
  } while (0)
#define LOG_DEBUG_KV(label, value) \
  do { \
    if (cfg.serialLogLevel >= 3) { \
      Serial.print(label); \
      Serial.println(value); \
    } \
  } while (0)

// INMP441 - I2S RX
#define MIC_I2S_PORT I2S_NUM_0
#define MIC_WS 4
#define MIC_SCK 5
#define MIC_SD 6

// INMP441 L/R tied to GND usually means left channel. Set to 0 if your module is wired for right.
#ifndef MIC_CHANNEL_LEFT
#define MIC_CHANNEL_LEFT 1
#endif

// Software gain applied after converting INMP441 24-bit samples to int16.
// 0 = no gain, 3 = x8, 4 = x16. Start with 4 if avgAbs is under ~200 while speaking.
#ifndef MIC_GAIN_SHIFT
#define MIC_GAIN_SHIFT 4
#endif

#ifndef LOCAL_VAD_START_AVG
#define LOCAL_VAD_START_AVG 550
#endif

#ifndef LOCAL_VAD_START_MAX
#define LOCAL_VAD_START_MAX 3500
#endif

#ifndef LOCAL_VAD_STOP_AVG
#define LOCAL_VAD_STOP_AVG 260
#endif

#ifndef LOCAL_VAD_SILENCE_MS
#define LOCAL_VAD_SILENCE_MS 1200
#endif

#ifndef LOCAL_VAD_MAX_TURN_MS
#define LOCAL_VAD_MAX_TURN_MS 12000
#endif

#ifndef AUDIO_CAPTURE_DEBUG_ENABLED
#define AUDIO_CAPTURE_DEBUG_ENABLED 0
#endif

#ifndef AUDIO_CAPTURE_MAX_SECONDS
#define AUDIO_CAPTURE_MAX_SECONDS 15
#endif

#ifndef AUDIO_CAPTURE_WEB_PORT
#define AUDIO_CAPTURE_WEB_PORT 80
#endif

#ifndef TFT_BL_BRIGHTNESS
#define TFT_BL_BRIGHTNESS 255
#endif

#ifndef TFT_BL_PWM_FREQ
#define TFT_BL_PWM_FREQ 5000
#endif

#ifndef TFT_BL_PWM_RESOLUTION
#define TFT_BL_PWM_RESOLUTION 8
#endif

// MAX98357A - I2S TX
#define SPK_I2S_PORT I2S_NUM_1
#define SPK_BCLK 15
#define SPK_LRC 16
#define SPK_DOUT 7

// Gemini Live audio formats.
static const int MIC_SAMPLE_RATE = 16000;
static const int SPK_SAMPLE_RATE = 24000;
static const size_t WS_FRAGMENT_MAX = 131072;

// 100 ms of 16 kHz mono audio. Small enough for latency, large enough for JSON overhead.
static const size_t MIC_SAMPLES_PER_CHUNK = 1600;
static int32_t micRaw[MIC_SAMPLES_PER_CHUNK];
static int16_t micPcm16[MIC_SAMPLES_PER_CHUNK];

struct AudioChunk {
  uint8_t *data;
  size_t len;
};

WiFiClientSecure wsClient;
#if TFT_ENABLED
//Adafruit_ST7789 tft(TFT_CS, TFT_DC, TFT_MOSI, TFT_SCLK, TFT_RST);
Adafruit_ST7789 tft = Adafruit_ST7789(TFT_CS, TFT_DC, TFT_MOSI, TFT_SCLK, TFT_RST);
ChatDisplay chat(tft);
#endif
volatile bool wsConnected = false;
volatile bool setupComplete = false;
bool wasPttPressed = false;
bool setupPending = false;
bool textAudioTestSent = false;
bool geminiSessionActive = false;
bool geminiSessionStreaming = false;
bool geminiModelResponding = false;
bool waitingForGeminiResponse = false;
bool geminiDisconnectAfterTurnPending = false;
bool localVadSpeechActive = false;
volatile bool speakerPlaybackActive = false;
uint32_t setupReadyAtMs = 0;
uint32_t lastMicLogAtMs = 0;
uint32_t lastPttLogAtMs = 0;
uint32_t pttStartedAtMs = 0;
uint32_t lastSessionToggleAtMs = 0;
uint32_t lastLocalSpeechAtMs = 0;
uint32_t localVadTurnStartedAtMs = 0;
uint32_t localVadSilenceStartedAtMs = 0;
uint32_t audioChunksSent = 0;
int lastPttRaw = -1;
bool pttLockedUntilRelease = false;
String geminiExtraHeaders;
String pendingUserTranscript;
String pendingAiTranscript;
bool transcriptCommitScheduled = false;
uint32_t lastTranscriptUpdateAtMs = 0;
String userTranscript[TRANSCRIPT_HISTORY_MAX];
String aiTranscript[TRANSCRIPT_HISTORY_MAX];
uint8_t userTranscriptCount = 0;
uint8_t aiTranscriptCount = 0;
QueueHandle_t speakerQueue = nullptr;
DynamicJsonDocument geminiDoc(98304);
uint8_t *wsFragmentBuffer = nullptr;
size_t wsFragmentLen = 0;
size_t wsFragmentExpectedLen = 0;
WebServer audioCaptureServer(AUDIO_CAPTURE_WEB_PORT);

void setupDisplay();
void setupMicI2S();
void setupSpeakerI2S();
void playTestTone(uint16_t freqHz, uint16_t durationMs);
void playStartupJingle();
void speakerTask(void *param);
void connectWiFi();
void setupOTA();
void serviceOTA();
bool connectGemini();
void serviceWebSocket();
void setupRuntimeConfig();
bool saveRuntimeConfig();
void sendGeminiSetup();
void commitStaleTranscripts();
void appendTranscriptContext(String &prompt);
void handleSessionToggleButton();
void serviceGeminiAutoDisconnect();
void setupStatusLed();
void statusLedOff();
void statusLedListening();
void statusLedSpeaking();
void setupAudioCaptureWeb();
void serviceAudioCaptureWeb();
void setupConfigWebRoutes();
void configureAudioCaptureBuffer();
void audioCaptureBegin();
void audioCaptureAppend(const int16_t *samples, size_t sampleCount);
void audioCaptureEnd();
void streamMic();
void streamMicIfPressed();
void streamMicWithLocalVad();


// Implementation is split across numbered .ino tabs for readability.

void setup() {
  Serial.begin(115200);
  uint32_t serialStart = millis();
  while (!Serial && millis() - serialStart < 3000) {
    delay(10);
  }
  delay(300);

  setupRuntimeConfig();

  LOG_INFO("");
  LOG_INFO("=== Gemini ESP32-S3 raw websocket boot ===");
  LOG_INFO_KV("Gemini model: ", cfg.geminiModelName);
  LOG_INFO("WebSocket transport: raw WiFiClientSecure");
  setupStatusLed();
  setupDisplay();
  chat.begin();

  chat.info("Schermo OK");
  delay(500);
  chat.info("Seriale OK");
  delay(500);

#if GEMINI_USE_MANUAL_PTT || GEMINI_SESSION_TOGGLE_MODE
#if PTT_USE_INTERNAL_PULLUP
  pinMode(PTT_PIN, INPUT_PULLUP);
#else
  pinMode(PTT_PIN, INPUT);
#endif
  lastPttRaw = digitalRead(PTT_PIN);
  wasPttPressed = false;
  LOG_INFO_KV("PTT pin: ", PTT_PIN);
  LOG_INFO_KV("PTT initial raw: ", lastPttRaw);
  chat.info("Pulsante OK");
  delay(500);
#endif

  LOG_INFO("Starting I2S mic...");
  setupMicI2S();
  chat.info("Microfono OK");
  delay(500);
  LOG_INFO("Starting I2S speaker...");
  setupSpeakerI2S();
  chat.info("Speaker OK");
  delay(500);
#if SPEAKER_TEST_TONE_ON_BOOT
  LOG_INFO("Playing speaker startup jingle");
  playStartupJingle();
  LOG_INFO("Speaker startup jingle done");
#endif
  speakerQueue = xQueueCreate(128, sizeof(AudioChunk));
  xTaskCreatePinnedToCore(speakerTask, "speakerTask", 8192, nullptr, 2, nullptr, 1);
  LOG_INFO("Audio tasks ready");
  connectWiFi();
  setupOTA();
  setupAudioCaptureWeb();
  chat.info("WiFi OK");
  delay(500);
#if GEMINI_SESSION_TOGGLE_MODE
  chat.info("Premi per parlare...");
  LOG_INFO("Gemini socket idle. Press and release PTT to start listening; press and release again to disconnect.");
#else
  if (connectGemini()) {
    chat.info("Gemini OK");
  } else {
    chat.error("Gemini KO");
  }
  delay(500);
  LOG_INFO(GEMINI_USE_MANUAL_PTT ? "Hold PTT to stream audio to Gemini." : "Automatic VAD mode: streaming mic continuously.");
#endif
}

void loop() {
  serviceOTA();
  serviceAudioCaptureWeb();
  serviceWebSocket();
  commitStaleTranscripts();
  if (setupPending && wsConnected && millis() >= setupReadyAtMs) {
    setupPending = false;
    sendGeminiSetup();
  }
  if (GEMINI_SESSION_TOGGLE_MODE) {
    handleSessionToggleButton();
    serviceGeminiAutoDisconnect();
    if (geminiSessionActive && wsConnected && setupComplete && !geminiModelResponding && !waitingForGeminiResponse && !geminiDisconnectAfterTurnPending) {
      if (!geminiSessionStreaming) {
        geminiSessionStreaming = true;
        LOG_INFO("Gemini listening with local VAD");
        chat.setTitle("Ascolto ON");
        statusLedListening();
      }
      streamMicWithLocalVad();
    } else if (waitingForGeminiResponse) {
      if (geminiSessionStreaming) {
        chat.setTitle("Rispondo...");
      }
      geminiSessionStreaming = false;
      statusLedSpeaking();
    } else if (geminiModelResponding) {
      if (geminiSessionStreaming) {
        chat.setTitle("Rispondo...");
      }
      geminiSessionStreaming = false;
      statusLedSpeaking();
    }
  } else if (GEMINI_USE_MANUAL_PTT) {
    streamMicIfPressed();
  } else {
    streamMic();
  }
}
