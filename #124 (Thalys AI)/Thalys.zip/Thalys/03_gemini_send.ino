String jsonEscapeString(const char *text) {
  String escaped;
  if (!text) return escaped;

  while (*text) {
    char c = *text++;
    if (c == '"' || c == '\\') {
      escaped += '\\';
      escaped += c;
    } else if (c == '\n') {
      escaped += "\\n";
    } else if (c == '\r') {
      escaped += "\\r";
    } else if (c == '\t') {
      escaped += "\\t";
    } else {
      escaped += c;
    }
  }

  return escaped;
}

void appendTranscriptContext(String &prompt) {
  if (!cfg.geminiSendTranscriptContext) return;

  uint8_t maxCount = max(userTranscriptCount, aiTranscriptCount);
  if (maxCount == 0) return;

  uint8_t turns = min(cfg.geminiContextTurns, maxCount);
  if (turns == 0) return;

  uint8_t start = maxCount - turns;
  prompt += "\n\nContesto recente della conversazione precedente. Usalo solo per mantenere memoria tra sessioni, senza citarlo se non serve:\n";

  for (uint8_t i = start; i < maxCount; i++) {
    if (i < userTranscriptCount && userTranscript[i].length() > 0) {
      prompt += "Utente: ";
      prompt += userTranscript[i];
      prompt += "\n";
    }
    if (i < aiTranscriptCount && aiTranscript[i].length() > 0) {
      prompt += "Thalys: ";
      prompt += aiTranscript[i];
      prompt += "\n";
    }
  }
}

void sendGeminiSetup() {
  String message = "{";
  message += "\"setup\":{";
  message += "\"model\":\"models/";
  message += jsonEscapeString(cfg.geminiModelName.c_str());
  message += "\",";
  message += "\"generationConfig\":{\"responseModalities\":[\"AUDIO\"]";
#if GEMINI_USE_SPEECH_CONFIG
  message += ",\"speechConfig\":{\"voiceConfig\":{\"prebuiltVoiceConfig\":{\"voiceName\":\"";
  message += jsonEscapeString(cfg.geminiVoiceName.c_str());
  message += "\"}},\"languageCode\":\"it-IT\"}";
#endif
  message += "}";

#if GEMINI_USE_MANUAL_PTT || GEMINI_SESSION_TOGGLE_MODE
  message += ",";
  message += "\"realtimeInputConfig\":{\"automaticActivityDetection\":{\"disabled\":true}}";
#endif

#if GEMINI_ENABLE_TRANSCRIPTIONS
  message += ",";
  message += "\"inputAudioTranscription\":{},";
  message += "\"outputAudioTranscription\":{}";
#endif

#if !GEMINI_MINIMAL_AUDIO_SETUP
#if !GEMINI_ENABLE_TRANSCRIPTIONS
  message += ",";
  message += "\"inputAudioTranscription\":{},";
  message += "\"outputAudioTranscription\":{}";
#endif

#if GEMINI_SEND_SYSTEM_INSTRUCTION
  message += ",";
  String systemPrompt = cfg.geminiSystemPrompt;
  appendTranscriptContext(systemPrompt);
  message += "\"systemInstruction\":{\"parts\":[{\"text\":\"";
  message += jsonEscapeString(systemPrompt.c_str());
  message += "\"}]}";
#endif
#endif

  message += "}}";

  sendWsText(message);
  LOG_INFO("Gemini setup sent");
  LOG_DEBUG_KV("Setup JSON: ", message);
}

void sendAudioChunk(const int16_t *samples, size_t sampleCount) {
  if (!wsConnected || !setupComplete) {
    LOG_DEBUG("Audio chunk skipped: WebSocket/setup not ready");
    return;
  }

  String audio64 = base64Encode((const uint8_t *)samples, sampleCount * sizeof(int16_t));
  if (audio64.length() == 0) {
    LOG_ERROR("Base64 encode failed");
    return;
  }

  String message;
  message.reserve(audio64.length() + 128);
  message += "{\"realtimeInput\":{\"audio\":{\"data\":\"";
  message += audio64;
  message += "\",\"mimeType\":\"audio/pcm;rate=16000\"}}}";

  audioCaptureAppend(samples, sampleCount);
  sendWsText(message);
  audioChunksSent++;
}

void sendTextAudioTest() {
  if (!wsConnected || !setupComplete || textAudioTestSent) return;
  textAudioTestSent = true;
  String message = "{\"clientContent\":{\"turns\":[{\"role\":\"user\",\"parts\":[{\"text\":\"Di soltanto: ciao, ti sento.\"}]}],\"turnComplete\":true}}";
  sendWsText(message);
  LOG_INFO("Text audio test sent");
}

void sendActivityStart() {
  LOG_INFO("PTT pressed");
  if (!wsConnected || !setupComplete) {
    LOG_INFO("PTT start skipped: WebSocket/setup not ready");
    return;
  }
  clearPendingTranscripts();
  audioCaptureBegin();
  sendWsText("{\"realtimeInput\":{\"activityStart\":{}}}");
  LOG_INFO("PTT start");
}

void sendActivityEnd() {
  LOG_INFO("PTT released");
  if (!wsConnected || !setupComplete) {
    LOG_INFO("PTT end skipped: WebSocket/setup not ready");
    return;
  }
  sendWsText("{\"realtimeInput\":{\"activityEnd\":{}}}");
  audioCaptureEnd();
  LOG_INFO("PTT end");
}
