static const char *RUNTIME_CONFIG_PATH = "/thalys_config.json";

uint8_t argToUint8(const char *name, uint8_t fallback, uint8_t minValue, uint8_t maxValue) {
  if (!audioCaptureServer.hasArg(name)) return fallback;
  int value = audioCaptureServer.arg(name).toInt();
  return (uint8_t)constrain(value, minValue, maxValue);
}

uint16_t argToUint16(const char *name, uint16_t fallback, uint16_t minValue, uint16_t maxValue) {
  if (!audioCaptureServer.hasArg(name)) return fallback;
  int value = audioCaptureServer.arg(name).toInt();
  return (uint16_t)constrain(value, minValue, maxValue);
}

bool argToBool(const char *name) {
  return audioCaptureServer.hasArg(name);
}

String argToString(const char *name, const String &fallback) {
  if (!audioCaptureServer.hasArg(name)) return fallback;
  return audioCaptureServer.arg(name);
}

void constrainRuntimeConfig() {
  cfg.serialLogLevel = constrain(cfg.serialLogLevel, 0, 3);
  cfg.geminiContextTurns = constrain(cfg.geminiContextTurns, 0, TRANSCRIPT_HISTORY_MAX);
  cfg.audioCaptureMaxSeconds = constrain(cfg.audioCaptureMaxSeconds, 1, 60);
  cfg.speakerVolumePercent = constrain(cfg.speakerVolumePercent, 0, 100);
  cfg.tftBacklightBrightness = constrain(cfg.tftBacklightBrightness, 0, 255);
  cfg.statusLedBrightness = constrain(cfg.statusLedBrightness, 0, 255);
  cfg.micGainShift = constrain(cfg.micGainShift, 0, 6);
  cfg.localVadStartAvg = constrain(cfg.localVadStartAvg, 0, 20000);
  cfg.localVadStartMax = constrain(cfg.localVadStartMax, 0, 32767);
  cfg.localVadStopAvg = constrain(cfg.localVadStopAvg, 0, 20000);
  cfg.localVadSilenceMs = constrain(cfg.localVadSilenceMs, 100, 5000);
  cfg.localVadMaxTurnMs = constrain(cfg.localVadMaxTurnMs, 1000, 60000);
  if (cfg.configWebUsername.length() == 0) cfg.configWebUsername = CONFIG_WEB_USERNAME;
  if (cfg.configWebPassword.length() == 0) cfg.configWebPassword = CONFIG_WEB_PASSWORD;
  if (cfg.geminiApiKey.length() == 0) cfg.geminiApiKey = GEMINI_API_KEY;
  if (cfg.geminiModelName.length() == 0) cfg.geminiModelName = GEMINI_MODEL_NAME;
  if (cfg.geminiVoiceName.length() == 0) cfg.geminiVoiceName = GEMINI_VOICE_NAME;
}

void applyRuntimeConfigNow() {
#if TFT_ENABLED
#if TFT_BL >= 0
  ledcWrite(TFT_BL, constrain(cfg.tftBacklightBrightness, 0, (1 << TFT_BL_PWM_RESOLUTION) - 1));
#endif
#endif
  uint8_t state = currentStatusLedState;
  currentStatusLedState = 255;
  setStatusLed(state);
}

void readRuntimeConfigString(DynamicJsonDocument &doc, const char *key, String &target) {
  const char *value = doc[key] | nullptr;
  if (value) target = value;
}

void loadRuntimeConfig() {
  if (!LittleFS.exists(RUNTIME_CONFIG_PATH)) {
    constrainRuntimeConfig();
    return;
  }

  File file = LittleFS.open(RUNTIME_CONFIG_PATH, "r");
  if (!file) {
    constrainRuntimeConfig();
    return;
  }

  DynamicJsonDocument doc(8192);
  DeserializationError error = deserializeJson(doc, file);
  file.close();
  if (error) {
    LOG_ERROR_KV("Runtime config JSON error: ", error.c_str());
    constrainRuntimeConfig();
    return;
  }

  readRuntimeConfigString(doc, "configWebUsername", cfg.configWebUsername);
  readRuntimeConfigString(doc, "configWebPassword", cfg.configWebPassword);
  cfg.serialLogLevel = doc["serialLogLevel"] | cfg.serialLogLevel;
  readRuntimeConfigString(doc, "geminiApiKey", cfg.geminiApiKey);
  readRuntimeConfigString(doc, "geminiModelName", cfg.geminiModelName);
  cfg.geminiUseEphemeralToken = doc["geminiUseEphemeralToken"] | cfg.geminiUseEphemeralToken;
  cfg.geminiUseQueryKey = doc["geminiUseQueryKey"] | cfg.geminiUseQueryKey;
  readRuntimeConfigString(doc, "geminiSystemPrompt", cfg.geminiSystemPrompt);
  readRuntimeConfigString(doc, "geminiVoiceName", cfg.geminiVoiceName);
  cfg.geminiSendTranscriptContext = doc["geminiSendTranscriptContext"] | cfg.geminiSendTranscriptContext;
  cfg.geminiContextTurns = doc["geminiContextTurns"] | cfg.geminiContextTurns;
  cfg.audioCaptureDebugEnabled = doc["audioCaptureDebugEnabled"] | cfg.audioCaptureDebugEnabled;
  cfg.audioCaptureMaxSeconds = doc["audioCaptureMaxSeconds"] | cfg.audioCaptureMaxSeconds;
  cfg.speakerVolumePercent = doc["speakerVolumePercent"] | cfg.speakerVolumePercent;
  cfg.tftBacklightBrightness = doc["tftBacklightBrightness"] | cfg.tftBacklightBrightness;
  cfg.statusLedBrightness = doc["statusLedBrightness"] | cfg.statusLedBrightness;
  cfg.micGainShift = doc["micGainShift"] | cfg.micGainShift;
  cfg.localVadStartAvg = doc["localVadStartAvg"] | cfg.localVadStartAvg;
  cfg.localVadStartMax = doc["localVadStartMax"] | cfg.localVadStartMax;
  cfg.localVadStopAvg = doc["localVadStopAvg"] | cfg.localVadStopAvg;
  cfg.localVadSilenceMs = doc["localVadSilenceMs"] | cfg.localVadSilenceMs;
  cfg.localVadMaxTurnMs = doc["localVadMaxTurnMs"] | cfg.localVadMaxTurnMs;
  constrainRuntimeConfig();
  LOG_INFO("Runtime config loaded");
}

bool saveRuntimeConfig() {
  constrainRuntimeConfig();

  DynamicJsonDocument doc(8192);
  doc["configWebUsername"] = cfg.configWebUsername;
  doc["configWebPassword"] = cfg.configWebPassword;
  doc["serialLogLevel"] = cfg.serialLogLevel;
  doc["geminiApiKey"] = cfg.geminiApiKey;
  doc["geminiModelName"] = cfg.geminiModelName;
  doc["geminiUseEphemeralToken"] = cfg.geminiUseEphemeralToken;
  doc["geminiUseQueryKey"] = cfg.geminiUseQueryKey;
  doc["geminiSystemPrompt"] = cfg.geminiSystemPrompt;
  doc["geminiVoiceName"] = cfg.geminiVoiceName;
  doc["geminiSendTranscriptContext"] = cfg.geminiSendTranscriptContext;
  doc["geminiContextTurns"] = cfg.geminiContextTurns;
  doc["audioCaptureDebugEnabled"] = cfg.audioCaptureDebugEnabled;
  doc["audioCaptureMaxSeconds"] = cfg.audioCaptureMaxSeconds;
  doc["speakerVolumePercent"] = cfg.speakerVolumePercent;
  doc["tftBacklightBrightness"] = cfg.tftBacklightBrightness;
  doc["statusLedBrightness"] = cfg.statusLedBrightness;
  doc["micGainShift"] = cfg.micGainShift;
  doc["localVadStartAvg"] = cfg.localVadStartAvg;
  doc["localVadStartMax"] = cfg.localVadStartMax;
  doc["localVadStopAvg"] = cfg.localVadStopAvg;
  doc["localVadSilenceMs"] = cfg.localVadSilenceMs;
  doc["localVadMaxTurnMs"] = cfg.localVadMaxTurnMs;

  File file = LittleFS.open(RUNTIME_CONFIG_PATH, "w");
  if (!file) {
    LOG_ERROR("Runtime config save failed");
    return false;
  }

  bool ok = serializeJsonPretty(doc, file) > 0;
  file.close();
  if (ok) LOG_INFO("Runtime config saved");
  return ok;
}

void setupRuntimeConfig() {
  if (!LittleFS.begin(true)) {
    LOG_ERROR("LittleFS mount failed");
    constrainRuntimeConfig();
    return;
  }

  loadRuntimeConfig();
}

bool requireConfigAuth() {
  if (audioCaptureServer.authenticate(cfg.configWebUsername.c_str(), cfg.configWebPassword.c_str())) {
    return true;
  }
  audioCaptureServer.requestAuthentication(BASIC_AUTH, "Thalys config");
  return false;
}

void appendNumberField(String &html, const char *name, const char *label, uint32_t value, uint32_t minValue, uint32_t maxValue) {
  html += "<label>";
  html += label;
  html += "<input type='number' name='";
  html += name;
  html += "' min='";
  html += String(minValue);
  html += "' max='";
  html += String(maxValue);
  html += "' value='";
  html += String(value);
  html += "'></label>";
}

void appendTextField(String &html, const char *name, const char *label, const String &value, bool password = false) {
  html += "<label>";
  html += label;
  html += "<input type='";
  html += password ? "password" : "text";
  html += "' name='";
  html += name;
  html += "' value='";
  html += htmlEscape(value);
  html += "'></label>";
}

void appendCheckboxField(String &html, const char *name, const char *label, bool checked) {
  html += "<label class='check'><input type='checkbox' name='";
  html += name;
  html += "'";
  if (checked) html += " checked";
  html += "> ";
  html += label;
  html += "</label>";
}

void handleConfigGet() {
  if (!requireConfigAuth()) return;

  String html;
  html.reserve(9000);
  html += "<!doctype html><html><head><meta charset='utf-8'>";
  html += "<meta name='viewport' content='width=device-width,initial-scale=1'>";
  html += "<title>Thalys config</title>";
  html += "<style>body{font-family:system-ui,sans-serif;margin:24px;background:#f6f7f9;color:#15171a}";
  html += "main{max-width:760px;margin:0 auto}form{display:grid;gap:14px}";
  html += "fieldset{border:1px solid #d5d9df;border-radius:8px;background:white;padding:16px}";
  html += "legend{font-weight:700}label{display:grid;gap:5px;margin:10px 0}";
  html += "input,textarea{font:inherit;padding:9px;border:1px solid #c6ccd4;border-radius:6px}";
  html += "textarea{min-height:120px}.check{display:block}";
  html += "button{font:inherit;background:#111;color:white;border:0;border-radius:6px;padding:11px 14px}";
  html += ".muted{color:#69707a}.top{display:flex;justify-content:space-between;gap:12px;align-items:center}</style></head><body><main>";
  html += "<div class='top'><h1>Configura Thalys</h1><a href='/'>Debug</a></div>";
  html += "<p class='muted'>I valori vengono salvati in LittleFS in <code>/thalys_config.json</code>. Pin e opzioni hardware restano nel firmware.</p>";
  html += "<form method='post' action='/config'>";

  html += "<fieldset><legend>Accesso pagina</legend>";
  appendTextField(html, "configWebUsername", "Utente", cfg.configWebUsername);
  appendTextField(html, "configWebPassword", "Password", cfg.configWebPassword, true);
  html += "</fieldset>";

  html += "<fieldset><legend>Gemini</legend>";
  appendTextField(html, "geminiApiKey", "API key / token", cfg.geminiApiKey, true);
  appendTextField(html, "geminiModelName", "Modello", cfg.geminiModelName);
  appendCheckboxField(html, "geminiUseEphemeralToken", "Usa token effimero", cfg.geminiUseEphemeralToken);
  appendCheckboxField(html, "geminiUseQueryKey", "Invia API key come parametro query", cfg.geminiUseQueryKey);
  html += "<label>Prompt iniziale<textarea name='geminiSystemPrompt'>";
  html += htmlEscape(cfg.geminiSystemPrompt);
  html += "</textarea></label>";
  appendTextField(html, "geminiVoiceName", "Voce", cfg.geminiVoiceName);
  appendCheckboxField(html, "geminiSendTranscriptContext", "Reinvia memoria conversazione", cfg.geminiSendTranscriptContext);
  appendNumberField(html, "geminiContextTurns", "Scambi di memoria", cfg.geminiContextTurns, 0, TRANSCRIPT_HISTORY_MAX);
  html += "</fieldset>";

  html += "<fieldset><legend>Audio e display</legend>";
  appendNumberField(html, "speakerVolumePercent", "Volume speaker %", cfg.speakerVolumePercent, 0, 100);
  appendNumberField(html, "tftBacklightBrightness", "Luminosita display", cfg.tftBacklightBrightness, 0, 255);
  appendNumberField(html, "statusLedBrightness", "Luminosita LED stato", cfg.statusLedBrightness, 0, 255);
  appendNumberField(html, "micGainShift", "Guadagno microfono shift", cfg.micGainShift, 0, 6);
  html += "</fieldset>";

  html += "<fieldset><legend>VAD locale</legend>";
  appendNumberField(html, "localVadStartAvg", "Start avg", cfg.localVadStartAvg, 0, 20000);
  appendNumberField(html, "localVadStartMax", "Start max", cfg.localVadStartMax, 0, 32767);
  appendNumberField(html, "localVadStopAvg", "Stop avg", cfg.localVadStopAvg, 0, 20000);
  appendNumberField(html, "localVadSilenceMs", "Silenzio ms", cfg.localVadSilenceMs, 100, 5000);
  appendNumberField(html, "localVadMaxTurnMs", "Turno max ms", cfg.localVadMaxTurnMs, 1000, 60000);
  html += "</fieldset>";

  html += "<fieldset><legend>Debug</legend>";
  appendNumberField(html, "serialLogLevel", "Log seriale", cfg.serialLogLevel, 0, 3);
  appendCheckboxField(html, "audioCaptureDebugEnabled", "Salva ultima acquisizione audio", cfg.audioCaptureDebugEnabled);
  appendNumberField(html, "audioCaptureMaxSeconds", "Secondi max acquisizione", cfg.audioCaptureMaxSeconds, 1, 60);
  html += "</fieldset>";

  html += "<button type='submit'>Salva parametri</button></form></main></body></html>";
  audioCaptureServer.send(200, "text/html; charset=utf-8", html);
}

void handleConfigPost() {
  if (!requireConfigAuth()) return;

  cfg.configWebUsername = argToString("configWebUsername", cfg.configWebUsername);
  cfg.configWebPassword = argToString("configWebPassword", cfg.configWebPassword);
  cfg.serialLogLevel = argToUint8("serialLogLevel", cfg.serialLogLevel, 0, 3);
  cfg.geminiApiKey = argToString("geminiApiKey", cfg.geminiApiKey);
  cfg.geminiModelName = argToString("geminiModelName", cfg.geminiModelName);
  cfg.geminiUseEphemeralToken = argToBool("geminiUseEphemeralToken");
  cfg.geminiUseQueryKey = argToBool("geminiUseQueryKey");
  cfg.geminiSystemPrompt = argToString("geminiSystemPrompt", cfg.geminiSystemPrompt);
  cfg.geminiVoiceName = argToString("geminiVoiceName", cfg.geminiVoiceName);
  cfg.geminiSendTranscriptContext = argToBool("geminiSendTranscriptContext");
  cfg.geminiContextTurns = argToUint8("geminiContextTurns", cfg.geminiContextTurns, 0, TRANSCRIPT_HISTORY_MAX);
  cfg.audioCaptureDebugEnabled = argToBool("audioCaptureDebugEnabled");
  cfg.audioCaptureMaxSeconds = argToUint16("audioCaptureMaxSeconds", cfg.audioCaptureMaxSeconds, 1, 60);
  cfg.speakerVolumePercent = argToUint8("speakerVolumePercent", cfg.speakerVolumePercent, 0, 100);
  cfg.tftBacklightBrightness = argToUint8("tftBacklightBrightness", cfg.tftBacklightBrightness, 0, 255);
  cfg.statusLedBrightness = argToUint8("statusLedBrightness", cfg.statusLedBrightness, 0, 255);
  cfg.micGainShift = argToUint8("micGainShift", cfg.micGainShift, 0, 6);
  cfg.localVadStartAvg = argToUint16("localVadStartAvg", cfg.localVadStartAvg, 0, 20000);
  cfg.localVadStartMax = argToUint16("localVadStartMax", cfg.localVadStartMax, 0, 32767);
  cfg.localVadStopAvg = argToUint16("localVadStopAvg", cfg.localVadStopAvg, 0, 20000);
  cfg.localVadSilenceMs = argToUint16("localVadSilenceMs", cfg.localVadSilenceMs, 100, 5000);
  cfg.localVadMaxTurnMs = argToUint16("localVadMaxTurnMs", cfg.localVadMaxTurnMs, 1000, 60000);

  bool ok = saveRuntimeConfig();
  applyRuntimeConfigNow();
  configureAudioCaptureBuffer();
  audioCaptureServer.sendHeader("Location", ok ? "/config?saved=1" : "/config?error=1");
  audioCaptureServer.send(303);
}

void setupConfigWebRoutes() {
  audioCaptureServer.on("/config", HTTP_GET, handleConfigGet);
  audioCaptureServer.on("/config", HTTP_POST, handleConfigPost);
}
