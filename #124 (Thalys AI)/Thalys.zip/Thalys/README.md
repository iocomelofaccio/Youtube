# Thalys

Prototype Arduino sketch for an ESP32-S3 N8R2 voice assistant using:

- INMP441 I2S microphone
- MAX98357A I2S amplifier
- ST7789 SPI display
- Gemini Live API over secure WebSocket

## Pins

```cpp
// INMP441
#define MIC_WS 4
#define MIC_SCK 5
#define MIC_SD 6

// MAX98357A
#define SPK_BCLK 15
#define SPK_LRC 16
#define SPK_DOUT 7

// ST7789
#define TFT_CS 41
#define TFT_RST 45
#define TFT_DC 40
#define TFT_MOSI 47
#define TFT_SCLK 21
#define TFT_BL 42
```

`SPK_DOUT` is ESP32 data out and goes to `DIN` on the MAX98357A.

## Arduino Libraries

Install these libraries from Arduino Library Manager:

- ArduinoJson by Benoit Blanchon
- WiFiManager by tzapu
- Adafruit GFX Library
- Adafruit ST7735 and ST7789 Library

`ChatDisplay` uses the built-in Adafruit GFX `FreeSans9pt7b` and `FreeSansBold9pt7b` fonts for a slightly smaller, smoother chat layout.

Use an ESP32 Arduino core that supports ESP32-S3. This variant uses a small raw WebSocket implementation on top of `WiFiClientSecure`, so it does not need the Markus Sattler `WebSockets` library or `esp_websocket_client`.

Runtime configuration is saved with `LittleFS`, included with the ESP32 Arduino core. Use a partition scheme with filesystem space available.

For Arduino IDE, select an ESP32-S3 board profile close to your module. For many ESP32-S3 N8R2 boards, start with:

- Board: `ESP32S3 Dev Module`
- Flash Size: `8MB`
- PSRAM: enabled if available in the menu
- USB CDC On Boot: enabled if you use USB serial

For PlatformIO, a starter `platformio.ini` is included.

## File Layout

The sketch is split into Arduino tabs for readability:

- `Thalys.ino`: configuration, global state, `setup()`, and `loop()`
- `01_transcripts_display.ino`: transcript cleanup, chat display updates, payload debug printing
- `02_audio_i2s_utils.ino`: Base64 helpers, JSON text fallback extraction, I2S setup
- `03_gemini_send.ino`: Gemini setup and outbound audio/activity messages
- `04_session_speaker.ino`: button/session toggle logic and speaker queue/playback
- `05_gemini_parse.ino`: incoming Gemini JSON/audio parsing
- `06_raw_websocket.ino`: raw WebSocket transport, WiFiManager, OTA, and Gemini connection
- `07_microphone.ino`: microphone capture and legacy hold-to-talk handling
- `08_status_led.ino`: onboard RGB LED state indicator
- `09_audio_capture_web.ino`: last microphone capture buffer and WAV download web page
- `10_runtime_config.ino`: password-protected runtime configuration page and LittleFS JSON persistence

## Configure

Copy `parameters.example.h` to `parameters.h`, then edit:

```cpp
#define WIFI_SSID "YOUR_WIFI_SSID"
#define WIFI_PASSWORD "YOUR_WIFI_PASSWORD"
#define WIFI_MANAGER_ENABLED 1
#define WIFI_MANAGER_AP_NAME "Thalys-Setup"
#define WIFI_MANAGER_AP_PASSWORD ""
#define WIFI_MANAGER_PORTAL_TIMEOUT_SEC 180
#define WIFI_MANAGER_CONNECT_TIMEOUT_SEC 20
#define WIFI_MANAGER_RESET_SETTINGS 0
#define OTA_FIRMWARE_UPDATE_ENABLED 1
#define OTA_HOSTNAME "Thalys"
#define OTA_PASSWORD ""
#define OTA_PORT 3232
#define GEMINI_API_KEY "YOUR_GEMINI_API_KEY"
#define GEMINI_USE_EPHEMERAL_TOKEN 0
#define GEMINI_USE_QUERY_KEY 1
#define GEMINI_MODEL_NAME "gemini-2.5-flash-native-audio-latest"
#define GEMINI_SEND_SYSTEM_INSTRUCTION 1
#define GEMINI_SYSTEM_PROMPT "Il tuo nome e Thalys sei un assistente vocale in italiano. Io sono Emanuele ed ho un canale Youtube che si chiama IoComeLoFaccio. Rispondi in modo breve, naturale e utile."
#define GEMINI_USE_SPEECH_CONFIG 1
#define GEMINI_TEXT_AUDIO_TEST_ON_SETUP 0
#define GEMINI_MINIMAL_AUDIO_SETUP 0
#define GEMINI_ENABLE_TRANSCRIPTIONS 1
#define TRANSCRIPT_HISTORY_MAX 20
#define GEMINI_SEND_TRANSCRIPT_CONTEXT 1
#define GEMINI_CONTEXT_TURNS 6
#define SERIAL_LOG_LEVEL 1
#define AUDIO_CAPTURE_DEBUG_ENABLED 1
#define AUDIO_CAPTURE_MAX_SECONDS 15
#define AUDIO_CAPTURE_WEB_PORT 80
#define CONFIG_WEB_USERNAME "admin"
#define CONFIG_WEB_PASSWORD "thalys"
#define GEMINI_USE_MANUAL_PTT 1
#define GEMINI_SESSION_TOGGLE_MODE 1
#define GEMINI_DISCONNECT_AFTER_TURN 1
#define GEMINI_VOICE_NAME "Aoede"
#define SPEAKER_TEST_TONE_ON_BOOT 0
#define SPEAKER_VOLUME_PERCENT 70
#define SPEAKER_JITTER_BUFFER_CHUNKS 3
#define SPEAKER_JITTER_BUFFER_MS 150
#define PTT_PIN 8
#define PTT_ACTIVE_LOW 1
#define PTT_USE_INTERNAL_PULLUP 1
#define PTT_MAX_HOLD_MS 4500
#define STATUS_RGB_LED_ENABLED 1
#define STATUS_RGB_LED_PIN 48
#define STATUS_RGB_LED_BRIGHTNESS 32
#define TFT_ENABLED 1
#define TFT_CS 41
#define TFT_RST 45
#define TFT_DC 40
#define TFT_MOSI 47
#define TFT_SCLK 21
#define TFT_BL 42
#define TFT_BL_BRIGHTNESS 180
#define TFT_BL_PWM_FREQ 5000
#define TFT_BL_PWM_RESOLUTION 8
#define TFT_WIDTH 240
#define TFT_HEIGHT 240
#define TFT_ROTATION 2
#define MIC_CHANNEL_LEFT 1
#define MIC_GAIN_SHIFT 4
#define LOCAL_VAD_START_AVG 550
#define LOCAL_VAD_START_MAX 3500
#define LOCAL_VAD_STOP_AVG 260
#define LOCAL_VAD_SILENCE_MS 1200
#define LOCAL_VAD_MAX_TURN_MS 12000
```

`GEMINI_API_KEY` can be either:

- an AI Studio API key, including new auth keys that may start with `AQ...`
- a short-lived Live API ephemeral token generated by your backend

With `WIFI_MANAGER_ENABLED 1`, Thalys uses tzapu WiFiManager. On first boot, or when saved credentials fail, it creates an access point named by `WIFI_MANAGER_AP_NAME` and opens a configuration portal. Connect to that access point from your phone/computer and enter the Wi-Fi credentials. `WIFI_SSID` and `WIFI_PASSWORD` remain as fallback values only when `WIFI_MANAGER_ENABLED` is set to `0`.

With `OTA_FIRMWARE_UPDATE_ENABLED 1`, ArduinoOTA starts after Wi-Fi is connected. The board appears on the network with `OTA_HOSTNAME`; set `OTA_PASSWORD` if you want OTA uploads protected by a password.

Leave `GEMINI_USE_EPHEMERAL_TOKEN` at `0` for normal AI Studio API keys, including `AQ...` keys. Set it to `1` only if you are using a real Live API ephemeral token.

API keys use the native `v1beta` endpoint. `GEMINI_USE_QUERY_KEY=1` follows the official raw WebSocket example and sends the key as `?key=`. Set it to `0` to try the `x-goog-api-key` header instead. Ephemeral tokens use the `v1alpha` constrained `?access_token=` endpoint.

The default model is `gemini-2.5-flash-native-audio-latest`. A local WebSocket control test with the same setup returned `inlineData audio/pcm` chunks, so this is the preferred profile for speaker output.

`SERIAL_LOG_LEVEL` controls how much the Serial Monitor prints:

- `0`: silent
- `1`: errors only
- `2`: connection/status messages
- `3`: verbose debug, including PTT, mic levels, WebSocket frames, payload snippets, and audio byte counts

With `AUDIO_CAPTURE_DEBUG_ENABLED 1`, Thalys stores the last microphone turn in RAM/PSRAM as 16 kHz mono PCM16. Open `http://<board-ip>/` from a browser on the same Wi-Fi network to download `thalys_last_capture.wav` and review the conversation transcript in a simple chat view. The maximum saved audio duration is controlled by `AUDIO_CAPTURE_MAX_SECONDS`.

Open `http://<board-ip>/config` to edit runtime parameters from the browser. The page uses HTTP Basic Auth; initial credentials come from `CONFIG_WEB_USERNAME` and `CONFIG_WEB_PASSWORD`. Saved values are stored in LittleFS as `/thalys_config.json` and override the defaults from `parameters.h` at boot.

Runtime-editable values include Gemini API key/token, Gemini model, Gemini prompt, Gemini voice, conversation-memory settings, serial log level, audio-capture debug settings, speaker volume, display brightness, status LED brightness, microphone gain, and local VAD thresholds. Hardware pins, enabled libraries, Wi-Fi/OTA structural options, and other compile-time flags still belong in `parameters.h`.

The `/config` page is protected with Basic Auth, but saved settings are stored in plain JSON inside the ESP32 filesystem. Keep the board on a trusted local network and change `CONFIG_WEB_PASSWORD` before using it outside quick lab tests.

This firmware uses `generationConfig.responseModalities: ["AUDIO"]` plus `speechConfig`. With the tested native-audio model, putting `responseModalities` directly inside `setup` caused the server to close the WebSocket immediately.

If `chunksSent` increases but Gemini does not react, watch `Mic avgAbs` while speaking. Values around `10-30` are almost silence. Try `MIC_GAIN_SHIFT=4` or `5`; if it stays low, flip `MIC_CHANNEL_LEFT` to `0`.

With `GEMINI_SESSION_TOGGLE_MODE 1`, the ESP32 does not open the Gemini WebSocket at boot. Press and release the PTT button once to connect and start listening. The ESP32 uses local voice activity detection: when your voice crosses the local threshold it sends `activityStart`, and after silence it sends `activityEnd`. Press and release the PTT button again to stop listening and disconnect the WebSocket.

With `GEMINI_DISCONNECT_AFTER_TURN 1`, Thalys uses one-shot sessions: after Gemini finishes speaking, the ESP32 waits for the speaker queue to drain, disconnects the WebSocket, and returns to `Premi per parlare...`. Press the button again for the next command.

With `GEMINI_SEND_TRANSCRIPT_CONTEXT 1`, each new Gemini setup includes the last `GEMINI_CONTEXT_TURNS` saved transcript turns inside the system instruction. This gives Thalys short conversation memory even though the WebSocket is disconnected after each answer.

If the display shows `Ascolto ON` but Gemini does not answer, temporarily set `SERIAL_LOG_LEVEL 3` and watch `Mic avgAbs` and `maxAbs`. If speaking does not print `Local VAD speech start`, lower `LOCAL_VAD_START_AVG` or `LOCAL_VAD_START_MAX`. If the display stays on `Ti ascolto...`, increase `LOCAL_VAD_STOP_AVG` or reduce `LOCAL_VAD_SILENCE_MS`; `LOCAL_VAD_MAX_TURN_MS` forces a turn end as a safety fallback.

While Gemini is speaking, microphone streaming is paused to reduce speaker-to-mic echo. If `GEMINI_DISCONNECT_AFTER_TURN` is set to `0`, after `turnComplete` the ESP32 resumes listening automatically.

With `GEMINI_SESSION_TOGGLE_MODE 0`, the older push-to-talk flow is used: the important serial sequence is `PTT pressed`, `PTT start`, increasing `chunksSent`, then `PTT released`, `PTT end`. Gemini usually responds only after `activityEnd`, so release the button after speaking.

If `chunksSent` increases even when you are not pressing the button in the older PTT mode, your PTT pin is reading as permanently pressed. Avoid BOOT/GPIO0 on those boards: wire an external button between `GPIO8` and `GND`, and use `PTT_PIN 8`.

If Gemini transcribes and replies in text but you hear nothing, set `SPEAKER_TEST_TONE_ON_BOOT 1` once. If you hear the short 8-bit startup jingle, the MAX98357A path is fine and the issue is Gemini audio output/config. If you do not hear the jingle, check MAX98357A `DIN/BCLK/LRC`, power, gain/shutdown pin, speaker wiring, and common ground.

For output-audio debugging, temporarily set `GEMINI_TEXT_AUDIO_TEST_ON_SETUP 1`. After `setupComplete`, the ESP32 sends a short text turn that should produce `Gemini audio bytes=...` and play a spoken "ciao, ti sento" response without using the microphone.

If that still returns only `outputTranscription`, also set `GEMINI_MINIMAL_AUDIO_SETUP 1`. This removes input/output transcriptions and system instruction while keeping manual PTT activity control enabled.

Large incoming WebSocket frames are logged as `Raw WebSocket frame opcode=... len=...`. If audio frames arrive, the next important line is `Gemini audio bytes=...`. If a large frame stalls, the firmware prints `Raw WebSocket read timeout`.

Keep `GEMINI_USE_SPEECH_CONFIG 1` for the native-audio model. The firmware ignores text parts marked as `thought` and plays only `inlineData` PCM audio chunks.

This raw WebSocket variant parses large and fragmented frames directly, so it should receive Gemini audio chunks that the Arduino `WebSockets` library was dropping.

The ST7789 is initialized with `TFT_ROTATION 2` for 180-degree rotation. The backlight on `TFT_BL` uses LEDC PWM; adjust `TFT_BL_BRIGHTNESS` from `0` to `255` to change display brightness.

Transcriptions are stored in RAM in two separate arrays:

```cpp
String userTranscript[TRANSCRIPT_HISTORY_MAX];
String aiTranscript[TRANSCRIPT_HISTORY_MAX];
```

Each completed turn appends the user's transcription to `userTranscript` and Gemini's spoken/text response to `aiTranscript`. When the arrays are full, the oldest item is discarded.

## WebSocket Control Test

If the ESP32 connects and immediately disconnects after setup, test the same key from your computer:

```bash
node tools/test_gemini_live_ws.mjs
```

You should see `OK: setupComplete received`. To try a specific model:

```bash
node tools/test_gemini_live_ws.mjs gemini-3.1-flash-live-preview
```

## First Test

1. Upload the sketch.
2. Open Serial Monitor at `115200`.
3. On first boot, connect to the `Thalys-Setup` WiFiManager access point if the board has no saved Wi-Fi credentials.
4. Wait for Wi-Fi connection and the `Premi per parlare` display message.
5. Press the PTT button to open the Gemini WebSocket.
6. Speak normally; local VAD ends the turn after silence.
7. Listen for Gemini through the MAX98357A speaker.
8. Press and release the PTT button again to stop listening and disconnect Gemini.

## Notes

- Input audio sent to Gemini is PCM 16-bit mono at 16 kHz.
- Gemini audio output is expected as PCM 16-bit mono at 24 kHz.
- The sketch duplicates mono output into stereo I2S frames for the MAX98357A.
- The onboard RGB LED is green while listening, red while Gemini is speaking, and off when the session is stopped.
- With `GEMINI_SESSION_TOGGLE_MODE 1`, the button starts/stops the WebSocket session and local VAD sends explicit `activityStart` and `activityEnd`. With `GEMINI_SESSION_TOGGLE_MODE 0`, the older manual push-to-talk flow sends `activityStart` and `activityEnd` from the button hold/release.
- `beginSSL()` is used without a certificate fingerprint in this prototype. Add certificate validation or ephemeral tokens before treating this as production.
- If audio is very quiet or distorted, the INMP441 bit shift may need adjustment with `MIC_GAIN_SHIFT`.
