#pragma once  // Evita inclusioni multiple di questo file durante la compilazione.

// ============================================================
// Wi-Fi
// ============================================================

#define WIFI_SSID "YOUR_WIFI_SSID"  // Nome della rete Wi-Fi a cui collegare ESP32.
#define WIFI_PASSWORD "YOUR_WIFI_PASSWORD"  // Password della rete Wi-Fi.

// ============================================================
// WiFiManager
// ============================================================

#define WIFI_MANAGER_ENABLED 1  // 1 = usa WiFiManager per configurare/salvare la rete Wi-Fi.
#define WIFI_MANAGER_AP_NAME "Thalys-Setup"  // Nome dell'access point creato per configurare il Wi-Fi.
#define WIFI_MANAGER_AP_PASSWORD ""  // Password dell'access point di configurazione; vuota = rete aperta.
#define WIFI_MANAGER_PORTAL_TIMEOUT_SEC 180  // Secondi massimi di attesa nel portale WiFiManager.
#define WIFI_MANAGER_CONNECT_TIMEOUT_SEC 20  // Secondi massimi per tentare la connessione Wi-Fi salvata.
#define WIFI_MANAGER_RESET_SETTINGS 0  // 1 = cancella le credenziali Wi-Fi salvate a ogni avvio.

// ============================================================
// Aggiornamento firmware OTA
// ============================================================

#define OTA_FIRMWARE_UPDATE_ENABLED 1  // 1 = abilita l'aggiornamento firmware OTA via rete.
#define OTA_HOSTNAME "Thalys"  // Nome con cui la scheda appare negli strumenti OTA.
#define OTA_PASSWORD ""  // Password OTA; vuota = nessuna password richiesta.
#define OTA_PORT 3232  // Porta usata da ArduinoOTA.

// ============================================================
// Credenziali Gemini
// ============================================================

#define GEMINI_API_KEY "YOUR_GEMINI_API_KEY"  // Chiave API o token per accedere a Gemini Live.
#define GEMINI_USE_EPHEMERAL_TOKEN 0  // 0 = usa API key normale; 1 = usa token effimero generato da backend.
#define GEMINI_USE_QUERY_KEY 1  // 1 = invia la chiave come parametro ?key=; 0 = usa header x-goog-api-key.

// ============================================================
// Modello e comportamento Gemini
// ============================================================

#define GEMINI_MODEL_NAME "gemini-2.5-flash-native-audio-latest"  // Modello Gemini Live con supporto audio nativo.
#define GEMINI_SEND_SYSTEM_INSTRUCTION 1  // 1 = invia il prompt iniziale di sistema a Gemini.
#define GEMINI_SYSTEM_PROMPT "Il tuo nome e Thalys sei un assistente vocale in italiano. Io sono Emanuele ed ho un canale Youtube che si chiama IoComeLoFaccio. Rispondi in modo breve, naturale e utile."  // Prompt iniziale dell'assistente.
#define GEMINI_USE_SPEECH_CONFIG 1  // 1 = invia configurazione voce e lingua per la risposta audio.
#define GEMINI_VOICE_NAME "Aoede"  // Nome della voce Gemini usata per la sintesi audio.
#define GEMINI_TEXT_AUDIO_TEST_ON_SETUP 0  // 1 = invia un breve test testuale dopo il setup per verificare l'audio in uscita.
#define GEMINI_MINIMAL_AUDIO_SETUP 0  // 1 = riduce il setup Gemini al minimo per debug audio.
#define GEMINI_ENABLE_TRANSCRIPTIONS 1  // 1 = richiede trascrizione input utente e output AI.
#define TRANSCRIPT_HISTORY_MAX 20  // Numero massimo di messaggi salvati negli array delle trascrizioni.
#define GEMINI_SEND_TRANSCRIPT_CONTEXT 1  // 1 = reinvia a Gemini gli ultimi scambi come memoria dopo una disconnessione.
#define GEMINI_CONTEXT_TURNS 6  // Numero massimo di scambi precedenti da usare come contesto.

// ============================================================
// Log seriale
// ============================================================

#define SERIAL_LOG_LEVEL 1  // 0 = silenzioso, 1 = errori, 2 = stato, 3 = debug dettagliato.

// ============================================================
// Debug acquisizione audio
// ============================================================

#define AUDIO_CAPTURE_DEBUG_ENABLED 1  // 1 = salva l'ultima frase microfonica e la rende scaricabile via web.
#define AUDIO_CAPTURE_MAX_SECONDS 15  // Durata massima dell'ultima acquisizione audio salvata in RAM/PSRAM.
#define AUDIO_CAPTURE_WEB_PORT 80  // Porta HTTP della pagina di download dell'ultima acquisizione WAV.
#define CONFIG_WEB_USERNAME "admin"  // Utente iniziale per accedere alla pagina /config.
#define CONFIG_WEB_PASSWORD "thalys"  // Password iniziale per accedere alla pagina /config.

// ============================================================
// Pulsante PTT / Toggle sessione
// ============================================================

#define GEMINI_USE_MANUAL_PTT 1  // 1 = abilita la logica legata al pulsante PTT.
#define GEMINI_SESSION_TOGGLE_MODE 1  // 1 = un click avvia la sessione Gemini, un altro click la ferma.
#define GEMINI_DISCONNECT_AFTER_TURN 1  // 1 = dopo la risposta chiude Gemini; per un nuovo comando serve ripremere il pulsante.
#define PTT_PIN 8  // GPIO del pulsante esterno collegato a GND.
#define PTT_ACTIVE_LOW 1  // 1 = pulsante premuto quando il pin legge LOW.
#define PTT_USE_INTERNAL_PULLUP 1  // 1 = abilita la pull-up interna sul pin del pulsante.
#define PTT_MAX_HOLD_MS 4500  // Durata massima di pressione nella vecchia modalita push-to-talk.

// ============================================================
// LED RGB onboard
// ============================================================

#define STATUS_RGB_LED_ENABLED 1  // 1 = abilita il LED RGB onboard come indicatore di stato.
#define STATUS_RGB_LED_PIN 48  // GPIO del LED RGB onboard; su molte ESP32-S3 e il pin 48.
#define STATUS_RGB_LED_BRIGHTNESS 32  // Luminosita del LED RGB da 0 a 255.

// ============================================================
// Speaker MAX98357A
// ============================================================

#define SPEAKER_TEST_TONE_ON_BOOT 0  // 1 = riproduce un breve jingle 8-bit all'avvio.
#define SPEAKER_VOLUME_PERCENT 70  // Volume software della risposta audio in percentuale.
#define SPEAKER_JITTER_BUFFER_CHUNKS 3  // Numero di chunk audio da accumulare prima della riproduzione.
#define SPEAKER_JITTER_BUFFER_MS 150  // Attesa massima del jitter buffer audio in millisecondi.

// ============================================================
// Display ST7789
// ============================================================

#define TFT_ENABLED 1  // 1 = abilita il display ST7789.
#define TFT_CS 41  // Pin Chip Select del display.
#define TFT_RST 45  // Pin Reset del display.
#define TFT_DC 40  // Pin Data/Command del display.
#define TFT_MOSI 47  // Pin dati SPI verso il display.
#define TFT_SCLK 21  // Pin clock SPI del display.
#define TFT_BL 42  // Pin backlight/LED del display.
#define TFT_BL_BRIGHTNESS 180  // Luminosita della retroilluminazione da 0 a 255.
#define TFT_BL_PWM_FREQ 5000  // Frequenza PWM della retroilluminazione in Hz.
#define TFT_BL_PWM_RESOLUTION 8  // Risoluzione PWM della retroilluminazione in bit.
#define TFT_WIDTH 240  // Larghezza del display in pixel.
#define TFT_HEIGHT 240  // Altezza del display in pixel.
#define TFT_ROTATION 2  // Rotazione del display; 2 = ruotato di 180 gradi.

// ============================================================
// Microfono INMP441
// ============================================================

#define MIC_CHANNEL_LEFT 1  // 1 = legge il canale sinistro; 0 = legge il canale destro.
#define MIC_GAIN_SHIFT 4  // Guadagno software del microfono: 4 equivale circa a x16.

// ============================================================
// VAD locale
// ============================================================

#define LOCAL_VAD_START_AVG 550  // Soglia media per riconoscere l'inizio della voce.
#define LOCAL_VAD_START_MAX 3500  // Soglia di picco per riconoscere l'inizio della voce.
#define LOCAL_VAD_STOP_AVG 260  // Soglia media sotto cui considerare silenzio.
#define LOCAL_VAD_SILENCE_MS 1200  // Millisecondi di silenzio necessari per chiudere il turno.
#define LOCAL_VAD_MAX_TURN_MS 12000  // Durata massima di un turno prima di forzare activityEnd.
