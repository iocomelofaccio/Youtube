bool isPttPressed() {
  int raw = digitalRead(PTT_PIN);
  return PTT_ACTIVE_LOW ? raw == LOW : raw == HIGH;
}

void clearSpeakerQueue() {
  if (!speakerQueue) return;

  AudioChunk chunk;
  while (xQueueReceive(speakerQueue, &chunk, 0) == pdTRUE) {
    free(chunk.data);
  }
}

void stopGeminiSession() {
  LOG_INFO("Gemini session stop");
  audioCaptureEnd();
  clearPendingTranscripts();
  clearSpeakerQueue();
  resetWsFragmentBuffer();

  wsClient.stop();
  wsConnected = false;
  setupComplete = false;
  setupPending = false;
  textAudioTestSent = false;
  geminiSessionActive = false;
  geminiSessionStreaming = false;
  geminiModelResponding = false;
  waitingForGeminiResponse = false;
  geminiDisconnectAfterTurnPending = false;
  localVadSpeechActive = false;
  speakerPlaybackActive = false;
  localVadTurnStartedAtMs = 0;
  localVadSilenceStartedAtMs = 0;
  wasPttPressed = false;
  pttLockedUntilRelease = false;
  audioChunksSent = 0;

  chat.setTitle("Ascolto OFF");
  statusLedOff();
}

void startGeminiSession() {
  if (geminiSessionActive || wsConnected) return;

  LOG_INFO("Gemini session start");
  clearPendingTranscripts();
  clearSpeakerQueue();
  audioChunksSent = 0;
  geminiSessionActive = true;
  geminiSessionStreaming = false;
  geminiModelResponding = false;
  waitingForGeminiResponse = false;
  geminiDisconnectAfterTurnPending = false;
  localVadSpeechActive = false;
  lastLocalSpeechAtMs = 0;
  localVadTurnStartedAtMs = 0;
  localVadSilenceStartedAtMs = 0;

  chat.setTitle("Connessione...");
  statusLedOff();
  if (!connectGemini()) {
    LOG_ERROR("Gemini session start failed");
    geminiSessionActive = false;
    geminiSessionStreaming = false;
    geminiModelResponding = false;
    waitingForGeminiResponse = false;
    geminiDisconnectAfterTurnPending = false;
    statusLedOff();
    return;
  }

  chat.setTitle("Pronto...");
}

void toggleGeminiSession() {
  uint32_t now = millis();
  if (now - lastSessionToggleAtMs < 500) return;
  lastSessionToggleAtMs = now;

  if (geminiSessionActive || wsConnected || setupPending) {
    stopGeminiSession();
  } else {
    startGeminiSession();
  }
}

void handleSessionToggleButton() {
  int raw = digitalRead(PTT_PIN);
  bool pressed = PTT_ACTIVE_LOW ? raw == LOW : raw == HIGH;
  uint32_t now = millis();

  if (raw != lastPttRaw) {
    lastPttRaw = raw;
    LOG_INFO_KV("PTT raw changed: ", raw);
  }

  if (now - lastPttLogAtMs > 1000) {
    lastPttLogAtMs = now;
    if (cfg.serialLogLevel >= 3) {
      Serial.print("Toggle raw=");
      Serial.print(raw);
      Serial.print(" pressed=");
      Serial.print(pressed ? "yes" : "no");
      Serial.print(" session=");
      Serial.println(geminiSessionActive ? "on" : "off");
    }
  }

  if (pressed && !wasPttPressed) {
    wasPttPressed = true;
    return;
  }

  if (!pressed && wasPttPressed) {
    wasPttPressed = false;
    LOG_INFO("Session button released");
    toggleGeminiSession();
  }
}

void serviceGeminiAutoDisconnect() {
#if GEMINI_DISCONNECT_AFTER_TURN
  if (!geminiDisconnectAfterTurnPending) return;

  bool speakerQueueBusy = speakerQueue && uxQueueMessagesWaiting(speakerQueue) > 0;
  if (speakerPlaybackActive || speakerQueueBusy) {
    statusLedSpeaking();
    return;
  }

  LOG_INFO("Gemini one-shot turn done; disconnecting");
  stopGeminiSession();
  chat.info("Premi per parlare...");
#endif
}

void playGeminiPcm24kMono(const uint8_t *pcmBytes, size_t byteLen) {
  const int16_t *mono = (const int16_t *)pcmBytes;
  size_t monoSamples = byteLen / sizeof(int16_t);

  // MAX98357A is happiest with stereo I2S frames. Duplicate mono to L/R.
  const size_t blockMonoSamples = 512;
  int16_t stereo[blockMonoSamples * 2];

  size_t offset = 0;
  while (offset < monoSamples) {
    size_t n = min(blockMonoSamples, monoSamples - offset);
    for (size_t i = 0; i < n; i++) {
      int16_t s = (int32_t)mono[offset + i] * cfg.speakerVolumePercent / 100;
      stereo[i * 2] = s;
      stereo[i * 2 + 1] = s;
    }

    size_t written = 0;
    i2s_write(SPK_I2S_PORT, stereo, n * 2 * sizeof(int16_t), &written, portMAX_DELAY);
    offset += n;
  }
}

void speakerTask(void *param) {
  AudioChunk chunk;
  bool jitterBufferActive = false;
  while (true) {
    if (xQueueReceive(speakerQueue, &chunk, portMAX_DELAY) == pdTRUE) {
      if (!jitterBufferActive && SPEAKER_JITTER_BUFFER_CHUNKS > 1) {
        uint32_t start = millis();
        while (uxQueueMessagesWaiting(speakerQueue) < SPEAKER_JITTER_BUFFER_CHUNKS - 1 &&
               millis() - start < SPEAKER_JITTER_BUFFER_MS) {
          delay(5);
        }
        jitterBufferActive = true;
      }

      speakerPlaybackActive = true;
      playGeminiPcm24kMono(chunk.data, chunk.len);
      free(chunk.data);

      if (uxQueueMessagesWaiting(speakerQueue) == 0) {
        jitterBufferActive = false;
        speakerPlaybackActive = false;
      }
    }
  }
}

void enqueueGeminiAudio(uint8_t *audio, size_t audioLen) {
  if (!speakerQueue) {
    free(audio);
    return;
  }

  AudioChunk chunk = {audio, audioLen};
  if (xQueueSend(speakerQueue, &chunk, 0) != pdTRUE) {
    LOG_ERROR("Speaker queue full; dropping audio chunk");
    free(audio);
  }
}

void enqueueRawAudioCopy(uint8_t *payload, size_t length) {
  if (!payload || length < 2) return;

  uint8_t *audio = (uint8_t *)malloc(length);
  if (!audio) {
    LOG_ERROR("Raw audio malloc failed");
    return;
  }

  memcpy(audio, payload, length);
  LOG_DEBUG_KV("Gemini raw audio bytes=", (uint32_t)length);
  enqueueGeminiAudio(audio, length);
}

void playTestTone(uint16_t freqHz, uint16_t durationMs) {
  const uint32_t totalSamples = (SPK_SAMPLE_RATE * durationMs) / 1000;
  const uint32_t period = SPK_SAMPLE_RATE / freqHz;
  int16_t stereo[128 * 2];
  uint32_t sampleIndex = 0;

  while (sampleIndex < totalSamples) {
    size_t n = min((uint32_t)128, totalSamples - sampleIndex);
    for (size_t i = 0; i < n; i++) {
      uint32_t pos = sampleIndex + i;
      int32_t envelope = 15000;
      if (pos < SPK_SAMPLE_RATE / 100) {
        envelope = (int32_t)pos * 15000 / (SPK_SAMPLE_RATE / 100);
      } else if (totalSamples - pos < SPK_SAMPLE_RATE / 80) {
        envelope = (int32_t)(totalSamples - pos) * 15000 / (SPK_SAMPLE_RATE / 80);
      }
      int16_t s = (pos % period) < (period / 2) ? envelope : -envelope;
      stereo[i * 2] = s;
      stereo[i * 2 + 1] = s;
    }
    size_t written = 0;
    i2s_write(SPK_I2S_PORT, stereo, n * 2 * sizeof(int16_t), &written, portMAX_DELAY);
    sampleIndex += n;
  }
}

void playStartupJingle() {
  struct JingleNote {
    uint16_t freqHz;
    uint16_t durationMs;
    uint16_t pauseMs;
  };

  const JingleNote melody[] = {
    {523, 90, 18},
    {659, 90, 18},
    {784, 90, 18},
    {1047, 130, 25},
    {784, 85, 15},
    {1047, 180, 35},
    {1175, 100, 18},
    {1319, 220, 0},
  };

  for (size_t i = 0; i < sizeof(melody) / sizeof(melody[0]); i++) {
    playTestTone(melody[i].freqHz, melody[i].durationMs);
    if (melody[i].pauseMs > 0) delay(melody[i].pauseMs);
  }
}
