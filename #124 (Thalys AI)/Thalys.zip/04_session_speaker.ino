bool isPttPressed() {
  int raw = digitalRead(PTT_PIN);
  return PTT_ACTIVE_LOW ? raw == LOW : raw == HIGH;
}

void clearSpeakerQueue() {
  if (!speakerQueue) return;

  AudioChunk chunk;
  while (xQueueReceive(speakerQueue, &chunk, 0) == pdTRUE) {
    free(chunk.data);
  }
}

void stopGeminiSession() {
  LOG_INFO("Gemini session stop");
  clearPendingTranscripts();
  clearSpeakerQueue();
  resetWsFragmentBuffer();

  wsClient.stop();
  wsConnected = false;
  setupComplete = false;
  setupPending = false;
  textAudioTestSent = false;
  geminiSessionActive = false;
  geminiSessionStreaming = false;
  geminiModelResponding = false;
  localVadSpeechActive = false;
  localVadTurnStartedAtMs = 0;
  localVadSilenceStartedAtMs = 0;
  wasPttPressed = false;
  pttLockedUntilRelease = false;
  audioChunksSent = 0;

  chat.setTitle("Ascolto OFF");
  statusLedOff();
}

void startGeminiSession() {
  if (geminiSessionActive || wsConnected) return;

  LOG_INFO("Gemini session start");
  clearPendingTranscripts();
  clearSpeakerQueue();
  audioChunksSent = 0;
  geminiSessionActive = true;
  geminiSessionStreaming = false;
  geminiModelResponding = false;
  localVadSpeechActive = false;
  lastLocalSpeechAtMs = 0;
  localVadTurnStartedAtMs = 0;
  localVadSilenceStartedAtMs = 0;

  chat.setTitle("Connessione...");
  statusLedOff();
  if (!connectGemini()) {
    LOG_ERROR("Gemini session start failed");
    geminiSessionActive = false;
    geminiSessionStreaming = false;
    geminiModelResponding = false;
    chat.error("Gemini KO");
    statusLedOff();
    return;
  }

  chat.setTitle("Pronto...");
}

void toggleGeminiSession() {
  uint32_t now = millis();
  if (now - lastSessionToggleAtMs < 500) return;
  lastSessionToggleAtMs = now;

  if (geminiSessionActive || wsConnected || setupPending) {
    stopGeminiSession();
  } else {
    startGeminiSession();
  }
}

void handleSessionToggleButton() {
  int raw = digitalRead(PTT_PIN);
  bool pressed = PTT_ACTIVE_LOW ? raw == LOW : raw == HIGH;
  uint32_t now = millis();

  if (raw != lastPttRaw) {
    lastPttRaw = raw;
    LOG_INFO_KV("PTT raw changed: ", raw);
  }

  if (now - lastPttLogAtMs > 1000) {
    lastPttLogAtMs = now;
    if (SERIAL_LOG_LEVEL >= 3) {
      Serial.print("Toggle raw=");
      Serial.print(raw);
      Serial.print(" pressed=");
      Serial.print(pressed ? "yes" : "no");
      Serial.print(" session=");
      Serial.println(geminiSessionActive ? "on" : "off");
    }
  }

  if (pressed && !wasPttPressed) {
    wasPttPressed = true;
    return;
  }

  if (!pressed && wasPttPressed) {
    wasPttPressed = false;
    LOG_INFO("Session button released");
    toggleGeminiSession();
  }
}

void playGeminiPcm24kMono(const uint8_t *pcmBytes, size_t byteLen) {
  const int16_t *mono = (const int16_t *)pcmBytes;
  size_t monoSamples = byteLen / sizeof(int16_t);

  // MAX98357A is happiest with stereo I2S frames. Duplicate mono to L/R.
  const size_t blockMonoSamples = 512;
  int16_t stereo[blockMonoSamples * 2];

  size_t offset = 0;
  while (offset < monoSamples) {
    size_t n = min(blockMonoSamples, monoSamples - offset);
    for (size_t i = 0; i < n; i++) {
      int16_t s = (int32_t)mono[offset + i] * SPEAKER_VOLUME_PERCENT / 100;
      stereo[i * 2] = s;
      stereo[i * 2 + 1] = s;
    }

    size_t written = 0;
    i2s_write(SPK_I2S_PORT, stereo, n * 2 * sizeof(int16_t), &written, portMAX_DELAY);
    offset += n;
  }
}

void speakerTask(void *param) {
  AudioChunk chunk;
  bool playbackActive = false;
  while (true) {
    if (xQueueReceive(speakerQueue, &chunk, portMAX_DELAY) == pdTRUE) {
      if (!playbackActive && SPEAKER_JITTER_BUFFER_CHUNKS > 1) {
        uint32_t start = millis();
        while (uxQueueMessagesWaiting(speakerQueue) < SPEAKER_JITTER_BUFFER_CHUNKS - 1 &&
               millis() - start < SPEAKER_JITTER_BUFFER_MS) {
          delay(5);
        }
        playbackActive = true;
      }

      playGeminiPcm24kMono(chunk.data, chunk.len);
      free(chunk.data);

      if (uxQueueMessagesWaiting(speakerQueue) == 0) {
        playbackActive = false;
      }
    }
  }
}

void enqueueGeminiAudio(uint8_t *audio, size_t audioLen) {
  if (!speakerQueue) {
    free(audio);
    return;
  }

  AudioChunk chunk = {audio, audioLen};
  if (xQueueSend(speakerQueue, &chunk, 0) != pdTRUE) {
    LOG_ERROR("Speaker queue full; dropping audio chunk");
    free(audio);
  }
}

void enqueueRawAudioCopy(uint8_t *payload, size_t length) {
  if (!payload || length < 2) return;

  uint8_t *audio = (uint8_t *)malloc(length);
  if (!audio) {
    LOG_ERROR("Raw audio malloc failed");
    return;
  }

  memcpy(audio, payload, length);
  LOG_DEBUG_KV("Gemini raw audio bytes=", (uint32_t)length);
  enqueueGeminiAudio(audio, length);
}

void playTestTone(uint16_t freqHz, uint16_t durationMs) {
  const uint32_t totalSamples = (SPK_SAMPLE_RATE * durationMs) / 1000;
  const uint32_t period = SPK_SAMPLE_RATE / freqHz;
  int16_t stereo[128 * 2];
  uint32_t sampleIndex = 0;

  while (sampleIndex < totalSamples) {
    size_t n = min((uint32_t)128, totalSamples - sampleIndex);
    for (size_t i = 0; i < n; i++) {
      int16_t s = ((sampleIndex + i) % period) < (period / 2) ? 18000 : -18000;
      stereo[i * 2] = s;
      stereo[i * 2 + 1] = s;
    }
    size_t written = 0;
    i2s_write(SPK_I2S_PORT, stereo, n * 2 * sizeof(int16_t), &written, portMAX_DELAY);
    sampleIndex += n;
  }
}
