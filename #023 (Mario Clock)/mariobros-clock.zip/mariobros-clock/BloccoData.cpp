#include "BloccoData.h"

BloccoData::BloccoData(int x, int y) {
  _x = x;
  _y = y;
  _firstY = y;
  _width = 64;
  _height = 7;
}

void BloccoData::idle() {
  if (_state != IDLE) {
    // Serial.println("Block - Idle - Start");
    _lastState = _state;
    _state = IDLE;
    _y = _firstY;
  }
}

void BloccoData::hit() {
  if (_state != HIT) {
    _lastState = _state;
    _state = HIT;
    _lastY = _y;
    direction = UP;
  }
}

void BloccoData::setTextBlock() {
  Locator::getDisplay()->setTextColor(0xFFFF);
  Locator::getDisplay()->setCursor(_x, _y + 6);
  Locator::getDisplay()->print(_text);
}

void BloccoData::setText(String text) {
  _text = text;
}

void BloccoData::init() {
  Locator::getEventBus()->subscribe(this);
  setTextBlock();
}

void BloccoData::update() {
  
  Locator::getDisplay()->fillRect(_x, _y, _width, _height, SKY_COLOR);
  setTextBlock();
}

void BloccoData::execute(EventType event, Sprite* caller) {
  if (event == EventType::MOVE) {
    if (this->collidedWith(caller)) {
      Serial.println("Collision detected");
      hit();
      Locator::getEventBus()->broadcast(EventType::COLLISION, this);
    }
  }
}

const char* BloccoData::name() {
  return "BLOCK";
}
