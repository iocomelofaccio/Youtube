
#ifndef Game_h
#define Game_h

const int DISPLAY_WIDTH = 64;
const int DISPLAY_HEIGHT = 64;

enum Direction {
    RIGHT,
    LEFT,
    UP,
    DOWN
};


#endif


